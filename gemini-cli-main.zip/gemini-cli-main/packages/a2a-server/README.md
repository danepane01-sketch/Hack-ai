# Gemini CLI A2A Server

## All code in this package is experimental and under active development

This package contains the A2A server implementation for the Gemini CLI.
