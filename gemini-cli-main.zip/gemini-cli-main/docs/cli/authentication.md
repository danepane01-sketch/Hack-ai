# Authentication setup

See: [Getting Started - Authentication Setup](../get-started/authentication.md).
