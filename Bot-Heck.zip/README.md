1000 Parabot System - Node.js (Skeleton)
======================================

Structure:
- /hub           -> hub WebSocket + HTTP server (port 4200)
- /bots/bot_worker.js -> generic worker script for a bot (call node bot_worker.js <botId> <port>)
- spawn_manager.js -> spawns many workers (node spawn_manager.js <count> <startPort>)
- memory files: each worker writes memory_<botId>.jsonl in its working dir

How to use (example):
1) Install dependencies for hub: cd hub && npm install
2) Install node-fetch for workers: npm install node-fetch@2 ws express body-parser cors
   (or run globally)
3) Start hub: npm run start-hub
4) Start workers via spawn manager: node spawn_manager.js 1000 4301
   (this spawns 1000 node processes; ensure machine resources)
5) Ensure Ollama HTTP API is reachable (OLLAMA_BASE_URL env), default http://localhost:11434

Notes:
- This is a skeleton to run up to 1000 bots. Running 1000 node processes may be heavy; consider containerization
  or using clusters/workers on multiple machines.
- For production, add authentication, TLS, resource limits, monitoring, and rate-limits.


## Docker & Multiplex Worker
- Use `docker-compose up --build` to start hub and one multiplex worker.
- Configure environment variables in docker-compose.yml: BOT_COUNT and START_BOT if you want to run multiple workers to cover 1000 bots.
- Multiplex worker will create group WebSocket connections to the hub to register bot IDs and expose /api/:botId/message endpoints.


## Programming Feature Integration
- Use hub endpoint POST /send_program/:botId with JSON body { topic, prompt, provider }
- Or call worker HTTP endpoint POST /api/:botId/programming to request programming explanations
- To enable large token generation (100k), set GROQ_API_KEY in env and set provider:'groq' in request body
- Infinite-memory placeholders are written to memory_<botId>.jsonl and memory_vec_<botId>.json


## Production Upgrade Notes
- Set GROQ_API_KEY and GROQ_API_BASE to enable large-token programming via Groq (100k tokens).
- Set HUB_API_KEY and WORKER_API_KEY to secure endpoints. Use header 'x-api-key'.
- Multiplex worker now saves vectors to vectors.jsonl and supports naive queryVectors(). Replace with Milvus/FAISS for production.
- Autonomous tasks: queue tasks by appending JSON lines to tasks.jsonl in worker dir. Worker will pick and execute.
