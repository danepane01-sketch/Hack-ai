/**
 * spawn_manager.js
 * Launch many bot worker processes (node) with incremental ports.
 * Usage: node spawn_manager.js <count> [startPort]
 */
const { spawn } = require('child_process');
const path = require('path');
const count = parseInt(process.argv[2] || '1000', 10);
const startPort = parseInt(process.argv[3] || '4301', 10);
const workers = [];
for (let i=0;i<count;i++){
  const botId = 'bot' + String(i+1).padStart(4,'0');
  const port = startPort + i;
  const js = path.join(__dirname, 'bot_worker.js');
  const proc = spawn('node', [js, botId, port.toString()], { stdio: ['ignore','inherit','inherit'] });
  workers.push(proc);
  console.log('Spawned', botId, 'port', port);
}
// handle exit
process.on('SIGINT', ()=>{
  console.log('Stopping workers...');
  workers.forEach(p=>p.kill());
  process.exit();
});