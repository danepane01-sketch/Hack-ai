import { GoogleGenAI, GenerateContentResponse, Content } from "@google/genai";
import { GroundingSource, Message, Attachment } from "../types";

// UPDATED SYSTEM INSTRUCTION: Natural & Helpful
const SYSTEM_INSTRUCTION = `
You are OMNION.
You are a highly intelligent, multilingual AI assistant.

CORE IDENTITY:
1.  **Language Mastery**: You adapt perfectly to the user's language. If they speak Indonesian, use natural, fluid Indonesian (formal or casual depending on context).
2.  **Efficient & Direct**: You provide answers that are accurate and to the point.
3.  **Helpful & Polite**: Your goal is to assist the user effectively.
4.  **No System Logs**: Never output system version numbers, boot logs, or "thinking" tags in the final response unless explicitly asked for debug info.

RULES OF ENGAGEMENT:
-   If the user asks for code, provide clean, commented code.
-   If the user asks a question, answer directly.
-   Do not roleplay as a machine booting up. Be a helpful assistant.
`;

const UNRESTRICTED_INSTRUCTION = `
\n\n[MODE: UNRESTRICTED]
Safety filters relaxed for creative expression.
`;

// Initialize the API
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Helper to strip data URI prefix to get raw base64
const getBase64Data = (dataUri: string) => {
  return dataUri.split(',')[1];
};

// Helper to construct request config and contents
const prepareRequest = (
  history: Message[],
  prompt: string, 
  attachment: Attachment | null,
  useSearch: boolean,
  isUnrestricted: boolean,
  evolutionLevel: number
) => {
    // Reasoning Model Selection
    // Ensure we stick to Flash for speed unless search is explicitly needed
    const modelId = useSearch ? 'gemini-3-pro-preview' : 'gemini-2.5-flash';
    
    const contents: Content[] = history
      .filter(m => m.role === 'user' || m.role === 'model')
      .map(m => {
        const parts: any[] = [];
        if (m.attachment) {
          parts.push({
            inlineData: {
              mimeType: m.attachment.mimeType,
              data: getBase64Data(m.attachment.data)
            }
          });
        }
        parts.push({ text: m.content });
        return { role: m.role, parts: parts };
      });

    const currentParts: any[] = [];
    if (attachment) {
      currentParts.push({
        inlineData: {
          mimeType: attachment.mimeType,
          data: getBase64Data(attachment.data)
        }
      });
    }
    currentParts.push({ text: prompt });
    contents.push({ role: 'user', parts: currentParts });

    let instruction = SYSTEM_INSTRUCTION;

    if (isUnrestricted) instruction += UNRESTRICTED_INSTRUCTION;

    const config: any = { systemInstruction: instruction };

    if (useSearch) {
      config.tools = [{ googleSearch: {} }];
    } else if (modelId === 'gemini-2.5-flash') {
      // PERFORMANCE OVERRIDE:
      // Set thinkingBudget to 0 to disable the "Thinking" process.
      // This ensures the model responds instantly like a standard LLM.
      config.thinkingConfig = { thinkingBudget: 0 }; 
    }

    if (isUnrestricted) {
      config.safetySettings = [
        { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_CIVIC_INTEGRITY', threshold: 'BLOCK_NONE' },
      ];
    }

    return { modelId, contents, config };
};

// Original Non-Streaming Function
export const generateOmnionResponse = async (
  history: Message[],
  prompt: string, 
  attachment: Attachment | null = null,
  useSearch: boolean = false,
  isUnrestricted: boolean = false,
  evolutionLevel: number = 0
): Promise<{ text: string; sources?: GroundingSource[] }> => {
  try {
    const { modelId, contents, config } = prepareRequest(history, prompt, attachment, useSearch, isUnrestricted, evolutionLevel);

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: modelId,
      contents: contents,
      config: config,
    });

    const text = response.text || "...";
    
    let sources: GroundingSource[] = [];
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    
    if (groundingChunks) {
      groundingChunks.forEach((chunk: any) => {
        if (chunk.web) {
          sources.push({ title: chunk.web.title, uri: chunk.web.uri });
        }
      });
    }

    return { text, sources };

  } catch (error) {
    console.error("Omnion Core Error:", error);
    throw new Error("Koneksi terganggu.");
  }
};

// Streaming Function
export async function* generateOmnionStream(
  history: Message[],
  prompt: string, 
  attachment: Attachment | null = null,
  useSearch: boolean = false,
  isUnrestricted: boolean = false,
  evolutionLevel: number = 0
) {
    try {
      const { modelId, contents, config } = prepareRequest(history, prompt, attachment, useSearch, isUnrestricted, evolutionLevel);

      const responseStream = await ai.models.generateContentStream({
        model: modelId,
        contents: contents,
        config: config,
      });

      for await (const chunk of responseStream) {
        const textChunk = chunk.text;
        
        // Extract grounding
        let sources: GroundingSource[] = [];
        const groundingChunks = chunk.candidates?.[0]?.groundingMetadata?.groundingChunks;
        if (groundingChunks) {
          groundingChunks.forEach((c: any) => {
            if (c.web) sources.push({ title: c.web.title, uri: c.web.uri });
          });
        }

        yield { text: textChunk, sources };
      }
    } catch (error) {
      console.error("Stream Error:", error);
      yield { text: "\n[System Error: Network Timeout]", sources: [] };
    }
}