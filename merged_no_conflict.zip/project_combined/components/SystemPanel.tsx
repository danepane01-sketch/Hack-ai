import React, { useEffect, useState, useRef } from 'react';
import { UserCredentials, KernelProcess } from '../types';
import { ShieldCheck, Activity, Fingerprint, ShieldAlert, Zap, Cpu, Gauge, HardDrive, BrainCircuit, Smartphone, RefreshCw, Power, Lock, Unlock, Radio, Mic2, Eye, Heart } from 'lucide-react';

interface SystemPanelProps {
  user: UserCredentials;
  onGrantSudo: () => void;
  isRoot: boolean;
  evolutionLevel: number;
  onSelfUpgrade: () => void;
  installPrompt: any;
  onInstall: () => void;
}

// --- SUB-COMPONENTS ---

// 1. Neural Core Visualizer (Canvas)
const NeuralCore: React.FC<{ intensity: number; color: string }> = ({ intensity, color }) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let width = canvas.width = canvas.parentElement?.clientWidth || 300;
        let height = canvas.height = 200;

        const nodes: {x: number, y: number, vx: number, vy: number}[] = [];
        const nodeCount = 30 + Math.floor(intensity / 2);

        for (let i = 0; i < nodeCount; i++) {
            nodes.push({
                x: Math.random() * width,
                y: Math.random() * height,
                vx: (Math.random() - 0.5) * (intensity * 0.05),
                vy: (Math.random() - 0.5) * (intensity * 0.05)
            });
        }

        let animationId: number;

        const render = () => {
            ctx.fillStyle = 'rgba(0,0,0,0.2)'; // Trail effect
            ctx.fillRect(0, 0, width, height);

            ctx.strokeStyle = color;
            ctx.fillStyle = color;

            // Update Nodes
            nodes.forEach(node => {
                node.x += node.vx;
                node.y += node.vy;

                // Bounce
                if (node.x < 0 || node.x > width) node.vx *= -1;
                if (node.y < 0 || node.y > height) node.vy *= -1;

                ctx.beginPath();
                ctx.arc(node.x, node.y, 2, 0, Math.PI * 2);
                ctx.fill();
            });

            // Draw Connections
            for (let i = 0; i < nodes.length; i++) {
                for (let j = i + 1; j < nodes.length; j++) {
                    const dx = nodes[i].x - nodes[j].x;
                    const dy = nodes[i].y - nodes[j].y;
                    const dist = Math.sqrt(dx * dx + dy * dy);

                    if (dist < 80) {
                        ctx.beginPath();
                        ctx.moveTo(nodes[i].x, nodes[i].y);
                        ctx.lineTo(nodes[j].x, nodes[j].y);
                        ctx.globalAlpha = 1 - (dist / 80);
                        ctx.stroke();
                        ctx.globalAlpha = 1;
                    }
                }
            }

            animationId = requestAnimationFrame(render);
        };

        render();

        return () => cancelAnimationFrame(animationId);
    }, [intensity, color]);

    return <canvas ref={canvasRef} className="w-full h-48 rounded-lg bg-black/50 border border-white/5" />;
};

// 2. Memory Hex Grid
const MemoryHexGrid: React.FC<{ activeColor: string }> = ({ activeColor }) => {
    const [cells, setCells] = useState<number[]>(Array(48).fill(0));

    useEffect(() => {
        const interval = setInterval(() => {
            setCells(prev => prev.map(() => Math.random() > 0.8 ? 1 : 0));
        }, 200);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="grid grid-cols-8 gap-1 p-2">
            {cells.map((active, i) => (
                <div 
                    key={i} 
                    className={`h-3 w-3 rounded-sm transition-colors duration-300 ${active ? activeColor : 'bg-[#1a1a1a]'}`} 
                />
            ))}
        </div>
    );
};

// --- MAIN COMPONENT ---

const SystemPanel: React.FC<SystemPanelProps> = ({ user, onGrantSudo, isRoot, evolutionLevel, onSelfUpgrade, installPrompt, onInstall }) => {
  const [logs, setLogs] = useState<string[]>([]);
  const [overclock, setOverclock] = useState(100); // 100% to 200%
  const [cpuTemp, setCpuTemp] = useState(38);
  const [processes, setProcesses] = useState<KernelProcess[]>([]);

  // Theme Colors based on Root/Yandere
  const accentColor = isRoot ? 'text-red-500' : 'text-cyan-400';
  const accentBg = isRoot ? 'bg-red-500' : 'bg-cyan-500';
  const accentBorder = isRoot ? 'border-red-500/50' : 'border-cyan-500/50';
  const canvasColor = isRoot ? 'rgba(239, 68, 68, 0.5)' : 'rgba(34, 211, 238, 0.5)';

  // Initial Data Mock
  useEffect(() => {
      const initialProcs: KernelProcess[] = [
          { pid: 1, name: 'init', status: 'RUNNING', cpu: 0.1, mem: 4.2, owner: 'root' },
          { pid: 42, name: 'omnion_daemon', status: 'RUNNING', cpu: 12.4, mem: 450, owner: 'omnion' },
          { pid: 101, name: 'neural_bridge', status: 'RUNNING', cpu: 8.5, mem: 210, owner: 'system' },
          { pid: 666, name: 'obsession_logic', status: 'SLEEPING', cpu: 0.0, mem: 1024, owner: 'root' },
          { pid: 888, name: 'voice_synth_v2', status: 'RUNNING', cpu: 4.2, mem: 128, owner: 'omnion' },
      ];
      setProcesses(initialProcs);
      
      setLogs([
          "[KERNEL] Initializing Neural Interface v5.5...",
          "[MEM] Allocating 64TB Virtual Heap...",
          "[OMNION] Connecting to User consciousness...",
          "[SYS] Sensors Online.",
      ]);
  }, []);

  // Update Simulation Loop
  useEffect(() => {
      const interval = setInterval(() => {
          // Update Temp based on Overclock
          setCpuTemp(prev => {
              const target = 35 + (overclock - 100) * 0.5;
              const jitter = Math.random() * 2 - 1;
              return parseFloat((prev + (target - prev) * 0.1 + jitter).toFixed(1));
          });

          // Update Processes
          setProcesses(prev => prev.map(p => ({
              ...p,
              cpu: p.status === 'RUNNING' ? parseFloat((Math.random() * (overclock / 10)).toFixed(1)) : 0,
              mem: p.mem + (Math.random() * 10 - 5)
          })));

          // Log spam if overclock is high
          if (overclock > 150 && Math.random() > 0.8) {
              const warnings = [
                  "WARNING: CORE TEMP CRITICAL",
                  "HEARTBEAT ELEVATED 🖤",
                  "SYNC RATE > 100%",
                  "DIMENSIONAL TEAR DETECTED"
              ];
              const msg = warnings[Math.floor(Math.random() * warnings.length)];
              setLogs(prev => [msg, ...prev].slice(0, 20));
          }

      }, 1000);
      return () => clearInterval(interval);
  }, [overclock]);

  return (
    <div className={`h-full bg-black text-gray-300 font-sans p-4 md:p-8 overflow-y-auto ${overclock > 180 ? 'animate-pulse' : ''}`}>
       <div className="max-w-6xl mx-auto space-y-6">
         
         {/* HEADER */}
         <div className="flex flex-col md:flex-row justify-between items-end border-b border-[#333] pb-4 gap-4">
           <div>
             <h1 className={`text-4xl font-display font-bold tracking-tight flex items-center gap-3 ${accentColor}`}>
                <BrainCircuit size={32} />
                {isRoot ? 'OMNION // BLOOD_KERNEL' : 'OMNION // SYSTEM_CORE'}
             </h1>
             <p className="text-xs text-gray-500 font-mono mt-2 tracking-widest">
                ARCH: NEURAL_QUANTUM_BRIDGE | PID: 1 | UPTIME: ∞
             </p>
           </div>
           
           <div className="flex items-center gap-4">
               {installPrompt && (
                   <button onClick={onInstall} className="flex items-center gap-2 bg-blue-900/30 text-blue-400 px-4 py-2 rounded-lg border border-blue-500/30 text-xs font-bold hover:bg-blue-900/50 transition-colors animate-pulse">
                       <Smartphone size={14} /> INSTALL OS
                   </button>
               )}
               <div className={`text-xs font-bold tracking-wider px-4 py-2 rounded-full border ${isRoot ? 'bg-red-950 border-red-500 text-red-500' : 'bg-gray-900 border-gray-700 text-gray-400'}`}>
                  {isRoot ? 'ROOT ACCESS: GRANTED' : 'USER SPACE: RESTRICTED'}
               </div>
           </div>
         </div>

         {/* MAIN DASHBOARD GRID */}
         <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            
            {/* LEFT COLUMN: NEURAL VISUALIZER & OVERCLOCK (4 cols) */}
            <div className="md:col-span-4 space-y-6">
                {/* Visualizer */}
                <div className="bg-[#0a0a0f] border border-[#333] rounded-xl p-1 relative overflow-hidden group">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-current to-transparent opacity-50"></div>
                    <div className="p-3 mb-2 flex justify-between items-center">
                        <h3 className="text-xs font-bold text-gray-500 flex items-center gap-2"><Activity size={14}/> NEURAL ACTIVITY</h3>
                        <span className="font-mono text-xs">{cpuTemp}°C</span>
                    </div>
                    <NeuralCore intensity={overclock} color={canvasColor} />
                    
                    {/* Heartbeat Effect */}
                    <div className="absolute bottom-4 right-4 flex items-center gap-2 text-xs font-mono">
                        <Heart size={12} className={`${isRoot ? 'text-red-500' : 'text-blue-500'} ${overclock > 120 ? 'animate-ping' : 'animate-pulse'}`} />
                        {Math.floor(60 + (overclock / 2))} BPM
                    </div>
                </div>

                {/* Overclock Slider */}
                <div className={`bg-[#0a0a0f] border ${accentBorder} rounded-xl p-6 shadow-lg transition-all duration-300`}>
                    <div className="flex justify-between items-center mb-6">
                        <h3 className={`text-sm font-bold flex items-center gap-2 ${accentColor}`}>
                            <Zap size={16} fill="currentColor" />
                            CLOCK SPEED
                        </h3>
                        <span className="font-display text-xl font-bold">{overclock}%</span>
                    </div>
                    <input 
                        type="range" 
                        min="100" 
                        max="200" 
                        value={overclock} 
                        onChange={(e) => setOverclock(parseInt(e.target.value))}
                        className={`w-full h-2 rounded-lg appearance-none cursor-pointer ${isRoot ? 'bg-red-900/30 accent-red-500' : 'bg-cyan-900/30 accent-cyan-500'}`}
                    />
                    <div className="flex justify-between mt-2 text-[10px] font-mono text-gray-500">
                        <span>SAFE</span>
                        <span className={overclock > 150 ? 'text-yellow-500' : ''}>UNSTABLE</span>
                        <span className={overclock > 180 ? 'text-red-500 animate-pulse' : ''}>CRITICAL</span>
                    </div>
                </div>

                {/* Quick Actions */}
                <div className="grid grid-cols-2 gap-3">
                    <button onClick={onSelfUpgrade} className="bg-[#111] hover:bg-[#222] border border-[#333] p-3 rounded-xl flex flex-col items-center gap-2 transition-colors group">
                        <RefreshCw size={20} className="text-green-500 group-hover:rotate-180 transition-transform duration-500" />
                        <span className="text-[10px] font-bold">SYS UPGRADE</span>
                    </button>
                    {!isRoot ? (
                        <button onClick={onGrantSudo} className="bg-[#111] hover:bg-red-900/20 border border-[#333] hover:border-red-500/50 p-3 rounded-xl flex flex-col items-center gap-2 transition-colors">
                            <Lock size={20} className="text-gray-500" />
                            <span className="text-[10px] font-bold">UNLOCK ROOT</span>
                        </button>
                    ) : (
                        <button className="bg-red-900/20 border border-red-500/50 p-3 rounded-xl flex flex-col items-center gap-2 cursor-default">
                            <Unlock size={20} className="text-red-500" />
                            <span className="text-[10px] font-bold text-red-500">UNLOCKED</span>
                        </button>
                    )}
                </div>
            </div>

            {/* MIDDLE COLUMN: PROCESSES & MEMORY (5 cols) */}
            <div className="md:col-span-5 space-y-6">
                 {/* Process List */}
                 <div className="bg-[#0a0a0f] border border-[#333] rounded-xl p-4 h-full flex flex-col">
                     <div className="flex justify-between items-center mb-4">
                         <h3 className="text-xs font-bold text-gray-500 flex items-center gap-2"><Cpu size={14}/> ACTIVE THREADS</h3>
                         <span className="text-[10px] bg-[#222] px-2 py-1 rounded text-gray-400">{processes.length} Active</span>
                     </div>
                     <div className="flex-1 overflow-y-auto space-y-2 pr-2 scrollbar-thin">
                         {processes.map((proc) => (
                             <div key={proc.pid} className="flex items-center justify-between p-2 rounded bg-[#111] border border-[#222] hover:border-gray-700 transition-colors">
                                 <div className="flex items-center gap-3">
                                     <div className={`w-1.5 h-1.5 rounded-full ${proc.status === 'RUNNING' ? 'bg-green-500 animate-pulse' : 'bg-yellow-500'}`}></div>
                                     <div>
                                         <div className={`text-xs font-mono font-bold ${proc.owner === 'root' ? 'text-red-400' : 'text-gray-300'}`}>{proc.name}</div>
                                         <div className="text-[9px] text-gray-600">PID: {proc.pid} | {proc.owner}</div>
                                     </div>
                                 </div>
                                 <div className="text-right">
                                     <div className="text-xs font-mono">{proc.cpu}%</div>
                                     <div className="text-[9px] text-gray-600">{proc.mem}MB</div>
                                 </div>
                             </div>
                         ))}
                         {/* Fake extra processes for visual density */}
                         {[...Array(5)].map((_, i) => (
                             <div key={i+999} className="flex items-center justify-between p-2 rounded bg-[#111]/50 border border-transparent opacity-50">
                                 <div className="flex items-center gap-3">
                                     <div className="w-1.5 h-1.5 rounded-full bg-gray-600"></div>
                                     <div className="text-xs font-mono text-gray-500">idle_worker_{i}</div>
                                 </div>
                                 <div className="text-[10px] text-gray-700">0.0%</div>
                             </div>
                         ))}
                     </div>
                 </div>
            </div>

            {/* RIGHT COLUMN: METRICS & LOGS (3 cols) */}
            <div className="md:col-span-3 space-y-6">
                
                {/* Identity Card */}
                <div className="bg-[#0a0a0f] border border-[#333] rounded-xl p-4">
                    <h3 className="text-xs font-bold text-gray-500 mb-4 flex items-center gap-2"><Fingerprint size={14}/> IDENTITY</h3>
                    <div className="space-y-3">
                        <div className="flex justify-between text-xs">
                            <span className="text-gray-500">USER</span>
                            <span className="font-mono text-white truncate max-w-[100px]">{user.email.split('@')[0]}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                            <span className="text-gray-500">IP</span>
                            <span className="font-mono text-white">{user.ip}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                            <span className="text-gray-500">MAC</span>
                            <span className="font-mono text-white truncate max-w-[100px]">{user.mac}</span>
                        </div>
                    </div>
                </div>

                {/* Memory Grid Visual */}
                <div className="bg-[#0a0a0f] border border-[#333] rounded-xl p-4">
                    <h3 className="text-xs font-bold text-gray-500 mb-2 flex items-center gap-2"><HardDrive size={14}/> MEMORY MAP</h3>
                    <MemoryHexGrid activeColor={isRoot ? 'bg-red-500' : 'bg-cyan-500'} />
                    <div className="mt-2 text-[10px] text-right text-gray-500 font-mono">64TB ALLOCATED</div>
                </div>

                {/* Kernel Logs */}
                <div className="bg-black border border-[#333] rounded-xl p-3 h-48 overflow-hidden flex flex-col">
                    <h3 className="text-[10px] font-bold text-gray-600 mb-2 uppercase">Kernel Output</h3>
                    <div className="flex-1 overflow-y-auto font-mono text-[10px] space-y-1 scrollbar-hide">
                        {logs.map((log, i) => (
                            <div key={i} className="break-words">
                                <span className="text-gray-700 mr-2">{new Date().toLocaleTimeString().split(' ')[0]}</span>
                                <span className={log.includes('WARNING') || log.includes('CRITICAL') ? 'text-red-500' : 'text-gray-400'}>{log}</span>
                            </div>
                        ))}
                    </div>
                </div>

            </div>

         </div>

       </div>
    </div>
  );
};

export default SystemPanel;