import React, { useState, useEffect } from 'react';
import { VirtualFile } from '../types';
import { Folder, File, Image as ImageIcon, Video, ChevronRight, Home, ArrowLeft, Search, Eye, Download, X, Film, FileText, Music } from 'lucide-react';

interface FileExplorerProps {
  isRoot: boolean;
}

// --- MOCK FILE SYSTEM DATA ---
// Simulating a persistent storage state
const MOCK_FILE_SYSTEM: VirtualFile[] = [
  {
    name: 'root',
    type: 'directory',
    size: 4096,
    permissions: 'rwx',
    owner: 'root',
    createdAt: new Date('2024-01-01'),
    children: [
      {
        name: 'system_logs',
        type: 'directory',
        size: 4096,
        permissions: 'r--',
        owner: 'root',
        createdAt: new Date(),
        children: [
            { name: 'kernel_panic.log', type: 'file', size: 1024, permissions: 'r--', owner: 'root', createdAt: new Date() },
            { name: 'auth.log', type: 'file', size: 2048, permissions: 'r--', owner: 'root', createdAt: new Date() }
        ]
      }
    ]
  },
  {
    name: 'home',
    type: 'directory',
    size: 4096,
    permissions: 'rwx',
    owner: 'root',
    createdAt: new Date('2024-01-01'),
    children: [
      {
        name: 'user',
        type: 'directory',
        size: 4096,
        permissions: 'rwx',
        owner: 'user',
        createdAt: new Date(),
        children: [
          {
            name: 'downloads',
            type: 'directory',
            size: 4096,
            permissions: 'rwx',
            owner: 'user',
            createdAt: new Date(),
            children: [
                { name: 'instruction_manual.pdf', type: 'file', size: 500000, permissions: 'rw-', owner: 'user', createdAt: new Date(), mimeType: 'application/pdf' }
            ]
          },
          {
            name: 'scripts',
            type: 'directory',
            size: 4096,
            permissions: 'rwx',
            owner: 'user',
            createdAt: new Date(),
            children: [
                { 
                    name: 'loading_animation.py', 
                    type: 'file', 
                    size: 850, 
                    permissions: 'rwx', 
                    owner: 'user', 
                    createdAt: new Date(), 
                    mimeType: 'text/x-python',
                    mediaUrl: '' // Not applicable for text
                }
            ]
          },
          {
            name: 'OMNION_GENERATIONS',
            type: 'directory',
            size: 4096,
            permissions: 'rwx',
            owner: 'omnion',
            createdAt: new Date(),
            children: [
                { 
                    name: 'cyberpunk_city_render.png', 
                    type: 'file', 
                    size: 2500000, 
                    permissions: 'rw-', 
                    owner: 'omnion', 
                    createdAt: new Date(),
                    mimeType: 'image/png',
                    mediaUrl: 'https://images.unsplash.com/photo-1515630278258-407f66498911?auto=format&fit=crop&w=800&q=80'
                },
                { 
                    name: 'neural_network_viz.jpg', 
                    type: 'file', 
                    size: 1800000, 
                    permissions: 'rw-', 
                    owner: 'omnion', 
                    createdAt: new Date(),
                    mimeType: 'image/jpeg',
                    mediaUrl: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&w=800&q=80'
                },
                { 
                    name: 'mainframe_breach_simulation.mp4', 
                    type: 'file', 
                    size: 15400000, 
                    permissions: 'rw-', 
                    owner: 'omnion', 
                    createdAt: new Date(),
                    mimeType: 'video/mp4',
                    mediaUrl: 'https://test-videos.co.uk/vids/jellyfish/mp4/h264/720/Jellyfish_720_10s.mp4' // Using a public test video
                },
                { 
                    name: 'ai_assistant_avatar.png', 
                    type: 'file', 
                    size: 900000, 
                    permissions: 'rw-', 
                    owner: 'omnion', 
                    createdAt: new Date(),
                    mimeType: 'image/png',
                    mediaUrl: 'https://images.unsplash.com/photo-1531746790731-6c087fecd65a?auto=format&fit=crop&w=800&q=80'
                },
                { 
                    name: 'data_stream_loop.mp4', 
                    type: 'file', 
                    size: 8400000, 
                    permissions: 'rw-', 
                    owner: 'omnion', 
                    createdAt: new Date(),
                    mimeType: 'video/mp4',
                    mediaUrl: 'https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4'
                }
            ]
          }
        ]
      }
    ]
  }
];

const FileExplorer: React.FC<FileExplorerProps> = ({ isRoot }) => {
  const [currentPath, setCurrentPath] = useState<VirtualFile[]>([]);
  const [currentFiles, setCurrentFiles] = useState<VirtualFile[]>(MOCK_FILE_SYSTEM);
  const [selectedFile, setSelectedFile] = useState<VirtualFile | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Set initial path to /home/user/OMNION_GENERATIONS for immediate gratification
  useEffect(() => {
    // Traverse manually to set initial view
    const home = MOCK_FILE_SYSTEM.find(f => f.name === 'home');
    if(home && home.children) {
        const user = home.children.find(f => f.name === 'user');
        if(user && user.children) {
            const gens = user.children.find(f => f.name === 'OMNION_GENERATIONS');
            if(gens) {
                setCurrentPath([home, user, gens]);
                setCurrentFiles(gens.children || []);
            }
        }
    }
  }, []);

  const handleNavigate = (folder: VirtualFile) => {
    if (folder.type !== 'directory') return;
    setCurrentPath([...currentPath, folder]);
    setCurrentFiles(folder.children || []);
    setSearchQuery('');
  };

  const handleNavigateUp = () => {
    if (currentPath.length === 0) return;
    const newPath = [...currentPath];
    newPath.pop(); // Remove current folder
    
    // Recalculate files based on new path
    if (newPath.length === 0) {
        setCurrentFiles(MOCK_FILE_SYSTEM);
    } else {
        const parent = newPath[newPath.length - 1];
        setCurrentFiles(parent.children || []);
    }
    setCurrentPath(newPath);
    setSearchQuery('');
  };

  const handleBreadcrumbClick = (index: number) => {
    const newPath = currentPath.slice(0, index + 1);
    const targetFolder = newPath[newPath.length - 1];
    setCurrentPath(newPath);
    setCurrentFiles(targetFolder.children || []);
    setSearchQuery('');
  };

  const handleFileClick = (file: VirtualFile) => {
      if (file.type === 'directory') {
          handleNavigate(file);
      } else {
          setSelectedFile(file);
      }
  };

  const filteredFiles = currentFiles.filter(f => 
    f.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatSize = (bytes: number) => {
      if (bytes === 0) return '0 B';
      const k = 1024;
      const sizes = ['B', 'KB', 'MB', 'GB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0a0f] text-gray-200 font-mono relative overflow-hidden">
        {/* Modal / Lightbox */}
        {selectedFile && (
            <div className="absolute inset-0 z-50 bg-black/95 backdrop-blur-xl flex flex-col items-center justify-center p-4 animate-in fade-in duration-200">
                <button 
                    onClick={() => setSelectedFile(null)}
                    className="absolute top-4 right-4 text-gray-400 hover:text-white p-4 z-50 rounded-full bg-gray-900/50"
                >
                    <X size={24} />
                </button>

                <div className="max-w-5xl max-h-[80%] w-full flex items-center justify-center bg-[#0d0e15] border border-gray-800 rounded-lg overflow-hidden shadow-2xl relative">
                    {/* Render Content */}
                    {selectedFile.mimeType?.startsWith('image/') && (
                        <img 
                            src={selectedFile.mediaUrl} 
                            alt={selectedFile.name} 
                            className="max-w-full max-h-[80vh] object-contain"
                        />
                    )}
                    {selectedFile.mimeType?.startsWith('video/') && (
                        <video 
                            src={selectedFile.mediaUrl} 
                            controls 
                            autoPlay 
                            className="max-w-full max-h-[80vh]"
                        />
                    )}
                    {!selectedFile.mimeType?.startsWith('image/') && !selectedFile.mimeType?.startsWith('video/') && (
                        <div className="flex flex-col items-center gap-4 p-12">
                            <FileText size={64} className="text-gray-600" />
                            <p className="text-xl">Preview not available for this file type.</p>
                            <p className="font-mono text-sm text-gray-500">{selectedFile.mimeType || 'unknown/binary'}</p>
                        </div>
                    )}
                </div>
                
                <div className="mt-4 text-center">
                    <h2 className="text-xl font-bold text-white">{selectedFile.name}</h2>
                    <p className="text-sm text-gray-400">{formatSize(selectedFile.size)} • {selectedFile.createdAt.toLocaleDateString()}</p>
                </div>
            </div>
        )}

        {/* Toolbar */}
        <div className="h-14 border-b border-gray-800 bg-[#0f111a]/80 backdrop-blur flex items-center px-4 justify-between shrink-0">
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar mask-gradient max-w-[70%]">
                <button 
                    onClick={() => {
                        setCurrentPath([]);
                        setCurrentFiles(MOCK_FILE_SYSTEM);
                    }}
                    className={`p-2 rounded hover:bg-gray-800 transition-colors ${currentPath.length === 0 ? 'text-omnion-accent' : 'text-gray-400'}`}
                >
                    <Home size={18} />
                </button>
                {currentPath.map((folder, idx) => (
                    <div key={idx} className="flex items-center gap-1 shrink-0 animate-in fade-in slide-in-from-left-2 duration-300">
                        <ChevronRight size={14} className="text-gray-600" />
                        <button 
                            onClick={() => handleBreadcrumbClick(idx)}
                            className={`text-sm px-2 py-1 rounded hover:bg-gray-800 whitespace-nowrap ${idx === currentPath.length - 1 ? 'text-white font-bold' : 'text-gray-400'}`}
                        >
                            {folder.name}
                        </button>
                    </div>
                ))}
            </div>

            <div className="flex items-center gap-2">
                 <div className="relative group">
                     <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500 group-focus-within:text-white transition-colors" size={14} />
                     <input 
                        type="text" 
                        placeholder="Search..." 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="bg-gray-900 border border-gray-700 rounded-full pl-8 pr-4 py-1.5 text-xs focus:outline-none focus:border-omnion-accent w-32 transition-all focus:w-48 placeholder-gray-600"
                     />
                 </div>
            </div>
        </div>

        {/* File Grid */}
        <div className="flex-1 overflow-y-auto p-4 scrollbar-thin">
            {currentPath.length > 0 && (
                 <button 
                    onClick={handleNavigateUp}
                    className="mb-4 flex items-center gap-2 text-sm text-gray-500 hover:text-white transition-colors bg-gray-900/50 px-3 py-1 rounded-full w-fit"
                >
                    <ArrowLeft size={14} /> Back
                </button>
            )}

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {filteredFiles.length === 0 && (
                    <div className="col-span-full flex flex-col items-center justify-center h-64 text-gray-600 opacity-50">
                        <Folder size={48} className="mb-2" />
                        <p>Directory is empty</p>
                    </div>
                )}

                {filteredFiles.map((file, idx) => (
                    <div 
                        key={idx}
                        onClick={() => handleFileClick(file)}
                        className="group relative bg-[#0f111a] border border-gray-800/50 rounded-xl p-3 flex flex-col items-center gap-3 hover:bg-gray-800 hover:border-omnion-accent/50 cursor-pointer transition-all duration-200 hover:-translate-y-1 active:scale-95 shadow-lg"
                    >
                        {/* Thumbnail / Icon */}
                        <div className="w-full aspect-square bg-gray-900 rounded-lg overflow-hidden flex items-center justify-center relative shadow-inner">
                            {file.type === 'directory' ? (
                                <Folder size={48} className="text-blue-500/80 group-hover:text-blue-400 transition-colors drop-shadow-[0_0_10px_rgba(59,130,246,0.2)]" />
                            ) : file.mimeType?.startsWith('image/') ? (
                                <>
                                    <img src={file.mediaUrl} alt={file.name} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/40 transition-opacity">
                                        <Eye className="text-white drop-shadow-md" size={24} />
                                    </div>
                                </>
                            ) : file.mimeType?.startsWith('video/') ? (
                                <>
                                    <div className="w-full h-full bg-black flex items-center justify-center relative">
                                        {/* Video grid preview placeholder */}
                                        <video src={file.mediaUrl} className="w-full h-full object-cover opacity-60" muted loop onMouseOver={e => e.currentTarget.play()} onMouseOut={e => e.currentTarget.pause()} />
                                        <div className="absolute inset-0 flex items-center justify-center">
                                            <Film size={24} className="text-purple-500 drop-shadow-[0_0_5px_rgba(168,85,247,0.5)]" />
                                        </div>
                                    </div>
                                    <div className="absolute bottom-1 right-1 bg-black/80 px-1 rounded text-[9px] text-white">MP4</div>
                                </>
                            ) : (
                                <File size={42} className="text-gray-500 group-hover:text-gray-400" />
                            )}
                        </div>

                        {/* Metadata */}
                        <div className="w-full text-center">
                            <p className="text-xs font-bold truncate w-full px-1" title={file.name}>{file.name}</p>
                            <p className="text-[10px] text-gray-500 mt-1">{file.type === 'directory' ? 'Folder' : formatSize(file.size)}</p>
                        </div>

                        {/* Quick Action (Download - Simulation) */}
                        {file.type === 'file' && (
                            <button className="absolute top-2 right-2 p-1.5 bg-black/60 backdrop-blur rounded-full opacity-0 group-hover:opacity-100 hover:bg-omnion-accent hover:text-white transition-all">
                                <Download size={14} />
                            </button>
                        )}
                    </div>
                ))}
            </div>
        </div>
    </div>
  );
};

export default FileExplorer;
