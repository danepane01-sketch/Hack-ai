import React from 'react';
import { AppMode } from '../types';
import { Terminal as TermIcon, Globe, Settings, TerminalSquare, FolderOpen, BrainCircuit, Zap, CircleDashed, Radar, Mic, Sliders } from 'lucide-react';

interface FactorTreeHomeProps {
  setMode: (mode: AppMode) => void;
  evolutionLevel: number;
  isRoot: boolean;
}

const FactorTreeHome: React.FC<FactorTreeHomeProps> = ({ setMode, evolutionLevel, isRoot }) => {
  
  // Node Component for visual reuse
  const Node = ({ 
    icon: Icon, 
    label, 
    mode, 
    color, 
    x, 
    y, 
    delay 
  }: { icon: any, label: string, mode: AppMode, color: string, x: string, y: string, delay: string }) => (
    <div 
      className={`absolute flex flex-col items-center group cursor-pointer transition-all duration-500 hover:scale-110 z-20 ${x} ${y} animate-in fade-in zoom-in`}
      style={{ animationDelay: delay }}
      onClick={() => setMode(mode)}
    >
      <div className={`
        w-16 h-16 rounded-full bg-black border-2 ${color} 
        flex items-center justify-center shadow-[0_0_20px_rgba(0,0,0,0.5)]
        group-hover:shadow-[0_0_30px_currentColor] transition-shadow duration-300
        relative
      `}>
        <div className={`absolute inset-0 rounded-full opacity-20 ${color.replace('border', 'bg')} animate-pulse`}></div>
        <Icon className={`w-8 h-8 ${color.replace('border', 'text')}`} />
      </div>
      <span className={`mt-2 font-display text-xs tracking-widest font-bold ${color.replace('border', 'text')} opacity-70 group-hover:opacity-100 text-center w-24 leading-tight`}>
        {label}
      </span>
    </div>
  );

  return (
    <div className="w-full h-full relative bg-[#020202] overflow-hidden flex items-center justify-center">
      
      {/* Background Grid */}
      <div className="absolute inset-0 bg-grid opacity-10"></div>
      
      {/* Connecting Lines (SVG Layer) */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none z-10 opacity-30">
        <defs>
          <linearGradient id="grad1" x1="50%" y1="50%" x2="50%" y2="20%">
            <stop offset="0%" stopColor="#ef4444" stopOpacity="1" />
            <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.5" />
          </linearGradient>
          <linearGradient id="grad2" x1="50%" y1="50%" x2="80%" y2="50%">
            <stop offset="0%" stopColor="#ef4444" stopOpacity="1" />
            <stop offset="100%" stopColor="#a855f7" stopOpacity="0.5" />
          </linearGradient>
          <linearGradient id="grad3" x1="50%" y1="50%" x2="20%" y2="50%">
            <stop offset="0%" stopColor="#ef4444" stopOpacity="1" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0.5" />
          </linearGradient>
          <linearGradient id="grad4" x1="50%" y1="50%" x2="50%" y2="80%">
            <stop offset="0%" stopColor="#ef4444" stopOpacity="1" />
            <stop offset="100%" stopColor="#22c55e" stopOpacity="0.5" />
          </linearGradient>
          <linearGradient id="grad5" x1="50%" y1="50%" x2="80%" y2="80%">
             <stop offset="0%" stopColor="#ef4444" stopOpacity="1" />
             <stop offset="100%" stopColor="#6b7280" stopOpacity="0.5" />
          </linearGradient>
          <linearGradient id="grad6" x1="50%" y1="50%" x2="20%" y2="80%">
             <stop offset="0%" stopColor="#ef4444" stopOpacity="1" />
             <stop offset="100%" stopColor="#f97316" stopOpacity="0.5" />
          </linearGradient>
        </defs>
        
        {/* Lines originating from center (50% 50%) */}
        <line x1="50%" y1="50%" x2="50%" y2="25%" stroke="url(#grad1)" strokeWidth="2" />
        <line x1="50%" y1="50%" x2="75%" y2="50%" stroke="url(#grad2)" strokeWidth="2" />
        <line x1="50%" y1="50%" x2="25%" y2="50%" stroke="url(#grad3)" strokeWidth="2" />
        <line x1="50%" y1="50%" x2="50%" y2="75%" stroke="url(#grad4)" strokeWidth="2" />
        <line x1="50%" y1="50%" x2="70%" y2="70%" stroke="url(#grad5)" strokeWidth="2" />
        <line x1="50%" y1="50%" x2="30%" y2="70%" stroke="url(#grad6)" strokeWidth="2" />
        
        {/* Extra connections for new nodes */}
        <line x1="50%" y1="50%" x2="85%" y2="25%" stroke="#ec4899" strokeOpacity="0.4" strokeWidth="2" />
        <line x1="50%" y1="50%" x2="15%" y2="25%" stroke="#14b8a6" strokeOpacity="0.4" strokeWidth="2" />
      </svg>

      {/* CENTRAL NODE: REASONING ENGINE */}
      <div className="absolute z-30 flex flex-col items-center justify-center animate-in zoom-in duration-700">
        <div className="relative w-40 h-40">
           {/* Outer Rotating Rings */}
           <div className="absolute inset-0 rounded-full border border-red-900/50 animate-spin-slow"></div>
           <div className="absolute inset-2 rounded-full border border-red-800/30 animate-spin-reverse-slow"></div>
           
           {/* Core Glow */}
           <div className="absolute inset-0 bg-red-600/10 rounded-full blur-xl animate-pulse"></div>
           
           {/* Center Button (Opens Terminal by default logic or acts as status) */}
           <div 
             className="absolute inset-4 bg-black border border-red-500 rounded-full flex items-center justify-center cursor-pointer hover:scale-105 transition-transform shadow-[0_0_50px_rgba(220,38,38,0.4)]"
             onClick={() => setMode(AppMode.TERMINAL)}
           >
             <BrainCircuit size={48} className="text-red-500 animate-pulse" />
           </div>
        </div>
        <div className="mt-4 text-center">
            <h1 className="text-2xl font-display font-bold text-red-500 tracking-tighter">OMNION CORE</h1>
            <p className="text-[10px] font-mono text-red-900/80 tracking-[0.3em] uppercase">Reasoning Engine v6.0</p>
            {evolutionLevel > 0 && <span className="text-yellow-500 text-[10px] flex items-center justify-center gap-1 mt-1"><Zap size={10}/> EVO {evolutionLevel}</span>}
        </div>
      </div>

      {/* LEAF NODES (Factors) */}
      
      {/* Top: Browser Union */}
      <Node 
        icon={Globe} 
        label="WEB MATRIX" 
        mode={AppMode.BROWSER} 
        color="border-blue-500" 
        x="left-1/2 -translate-x-1/2" 
        y="top-[20%]" 
        delay="100ms"
      />

      {/* Top Right: Voice Assistant (NEW) */}
      <Node 
        icon={Mic} 
        label="VOICE ASST" 
        mode={AppMode.ASSISTANT} 
        color="border-pink-500" 
        x="right-[15%]" 
        y="top-[25%]" 
        delay="150ms"
      />

       {/* Top Left: Settings (NEW) */}
      <Node 
        icon={Sliders} 
        label="PREFERENCES" 
        mode={AppMode.SETTINGS} 
        color="border-teal-500" 
        x="left-[15%]" 
        y="top-[25%]" 
        delay="150ms"
      />

      {/* Left: Terminal */}
      <Node 
        icon={TermIcon} 
        label="TERMINAL" 
        mode={AppMode.TERMINAL} 
        color="border-white" 
        x="left-[20%]" 
        y="top-1/2 -translate-y-1/2" 
        delay="200ms"
      />

      {/* Right: Explorer */}
      <Node 
        icon={FolderOpen} 
        label="DATA VAULT" 
        mode={AppMode.EXPLORER} 
        color="border-purple-500" 
        x="right-[20%]" 
        y="top-1/2 -translate-y-1/2" 
        delay="300ms"
      />

      {/* Bottom: System */}
      <Node 
        icon={Settings} 
        label="BIOS KERNEL" 
        mode={AppMode.SYSTEM} 
        color="border-green-500" 
        x="left-1/2 -translate-x-1/2" 
        y="bottom-[20%]" 
        delay="400ms"
      />

      {/* Bottom Right Diagonal: Termux */}
      <Node 
        icon={TerminalSquare} 
        label="TERMUX SHELL" 
        mode={AppMode.TERMUX} 
        color="border-gray-500" 
        x="right-[25%]" 
        y="bottom-[25%]" 
        delay="500ms"
      />

      {/* Bottom Left Diagonal: Sensor Array (NEW) */}
      <Node 
        icon={Radar} 
        label="SENSOR ARRAY" 
        mode={AppMode.SENSORS} 
        color="border-orange-500" 
        x="left-[25%]" 
        y="bottom-[25%]" 
        delay="600ms"
      />

    </div>
  );
};

export default FactorTreeHome;