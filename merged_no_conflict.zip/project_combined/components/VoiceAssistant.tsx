import React, { useState, useEffect } from 'react';
import { AppMode } from '../types';
import { Mic, MicOff, Video, VideoOff, Volume2, VolumeX, X, MoreVertical, Atom, Sparkles, BookOpen, UserCircle, PenTool, Radio } from 'lucide-react';

interface VoiceAssistantProps {
  setMode: (mode: AppMode) => void;
  isRoot: boolean;
}

const VoiceAssistant: React.FC<VoiceAssistantProps> = ({ setMode, isRoot }) => {
  const [activeTab, setActiveTab] = useState<'ask' | 'imagine'>('ask');
  const [isConnecting, setIsConnecting] = useState(true);
  
  // Functional States
  const [isMicOn, setIsMicOn] = useState(true);
  const [isVideoOn, setIsVideoOn] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);

  useEffect(() => {
    // Simulate connection
    const timer = setTimeout(() => setIsConnecting(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  // Quick Action Card
  const QuickCard = ({ icon: Icon, label, sub }: any) => (
    <button className="flex items-center gap-3 p-4 rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 shadow-sm hover:scale-105 transition-transform w-full text-left group">
        <div className="p-2 rounded-full bg-gray-100 dark:bg-gray-800 text-black dark:text-white group-hover:bg-blue-500 group-hover:text-white transition-colors">
            <Icon size={20} />
        </div>
        <div>
            <div className="font-bold text-sm text-gray-900 dark:text-white">{label}</div>
            <div className="text-[10px] text-gray-500">{sub}</div>
        </div>
        <div className="ml-auto text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity">
            <Sparkles size={12} fill="currentColor" />
        </div>
    </button>
  );

  return (
    <div className="h-full flex flex-col bg-white dark:bg-black text-gray-900 dark:text-gray-100 font-sans relative overflow-hidden transition-colors duration-500">
        
        {/* Soft Background Gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-blue-50/50 to-pink-50/50 dark:from-blue-900/10 dark:to-purple-900/10 pointer-events-none"></div>

        {/* Top Bar */}
        <div className="flex items-center justify-between p-4 z-10">
            <button onClick={() => setMode(AppMode.TERMINAL)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full">
                <MoreVertical size={24} className="rotate-90" />
            </button>
            
            <div className="flex bg-gray-100 dark:bg-gray-900 p-1 rounded-full shadow-inner">
                <button 
                    onClick={() => setActiveTab('ask')}
                    className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${activeTab === 'ask' ? 'bg-white dark:bg-gray-800 shadow text-black dark:text-white' : 'text-gray-500'}`}
                >
                    <div className="flex items-center gap-2"><Radio size={14}/> Ask</div>
                </button>
                <button 
                    onClick={() => setActiveTab('imagine')}
                    className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${activeTab === 'imagine' ? 'bg-white dark:bg-gray-800 shadow text-black dark:text-white' : 'text-gray-500'}`}
                >
                    <div className="flex items-center gap-2"><Sparkles size={14}/> Imagine</div>
                </button>
            </div>

            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full">
                <PenTool size={20} />
            </button>
        </div>

        {/* Quick Actions (Top Grid) */}
        <div className="px-4 grid grid-cols-2 sm:grid-cols-4 gap-3 z-10 mb-8">
            <QuickCard icon={Atom} label="Assistant" sub="Bantuan Umum" />
            <QuickCard icon={UserCircle} label="Therapist" sub="Curhat & Solusi" />
            <QuickCard icon={BookOpen} label="Storyteller" sub="Buat Cerita" />
            <QuickCard icon={Sparkles} label="Kid Mode" sub="Edukasi Anak" />
        </div>

        {/* Center Canvas (Visualizer) */}
        <div className="flex-1 flex flex-col items-center justify-center relative z-0">
             {/* The Logo from screenshot */}
             <div className="relative w-48 h-48 flex items-center justify-center">
                 <div className={`absolute inset-0 border-4 border-gray-200 dark:border-gray-800 rounded-full transition-opacity duration-500 ${isMicOn ? 'opacity-20 animate-[spin_10s_linear_infinite]' : 'opacity-10'}`}></div>
                 <div className={`absolute inset-4 border-2 border-gray-300 dark:border-gray-700 rounded-full transition-opacity duration-500 ${isMicOn ? 'opacity-20 animate-[spin_15s_linear_infinite_reverse]' : 'opacity-5'}`}></div>
                 
                 {/* Omnion Abstract Mark */}
                 <div className="relative">
                     <Atom size={80} className={`text-gray-300 dark:text-gray-700 transition-all duration-500 ${isMicOn ? 'opacity-100 scale-100' : 'opacity-50 scale-90'}`} />
                     <div className={`absolute inset-0 blur-2xl transition-all duration-1000 ${isConnecting ? 'opacity-0' : isMicOn ? 'opacity-100 bg-blue-500/20' : 'opacity-0'}`}></div>
                 </div>
                 
                 {/* Rotating slash line */}
                 {isMicOn && (
                    <div className="absolute w-[120%] h-1 bg-gradient-to-r from-transparent via-gray-300 dark:via-gray-600 to-transparent rotate-45 animate-pulse"></div>
                 )}
             </div>

             <div className="mt-8 text-sm text-gray-400 font-medium tracking-widest uppercase animate-pulse">
                 {isConnecting ? 'Menghubungkan...' : isMicOn ? 'Mendengarkan...' : 'Mikrofon Nonaktif'}
             </div>
        </div>

        {/* Bottom Bar */}
        <div className="p-6 pb-12 flex items-center justify-center gap-6 z-20">
            {/* Video Button */}
            <button 
                onClick={() => setIsVideoOn(!isVideoOn)}
                className={`w-14 h-14 rounded-2xl flex items-center justify-center hover:scale-110 transition-all ${isVideoOn ? 'bg-white dark:bg-gray-100 text-black shadow-lg' : 'bg-red-50 dark:bg-red-900/20 text-red-500'}`}
            >
                {isVideoOn ? <Video size={24} /> : <VideoOff size={24} />}
            </button>

            {/* Mic Button (Main) */}
            <button 
                onClick={() => setIsMicOn(!isMicOn)}
                className={`w-20 h-20 rounded-3xl flex items-center justify-center shadow-xl hover:scale-105 transition-all active:scale-95 ${isMicOn ? 'bg-gradient-to-tr from-pink-500 to-orange-400 text-white shadow-orange-500/30' : 'bg-gray-200 dark:bg-gray-800 text-gray-500'}`}
            >
                {isMicOn ? <Mic size={32} /> : <MicOff size={32} />}
            </button>

            {/* Speaker Button */}
            <button 
                onClick={() => setIsSpeakerOn(!isSpeakerOn)}
                className={`w-14 h-14 rounded-2xl flex items-center justify-center hover:scale-110 transition-all ${isSpeakerOn ? 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300' : 'bg-gray-200 dark:bg-gray-900 text-gray-600'}`}
            >
                {isSpeakerOn ? <Volume2 size={24} /> : <VolumeX size={24} />}
            </button>

            {/* Close */}
            <button 
                onClick={() => setMode(AppMode.TERMINAL)}
                className="w-14 h-14 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 flex items-center justify-center hover:scale-110 transition-transform ml-4"
            >
                <X size={24} />
            </button>
        </div>

    </div>
  );
};

export default VoiceAssistant;