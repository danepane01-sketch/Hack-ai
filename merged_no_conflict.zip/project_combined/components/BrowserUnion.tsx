import React, { useState, useEffect } from 'react';
import { generateOmnionResponse } from '../services/omnionService';
import { Search, ExternalLink, Globe, ShieldAlert, Lock, Unlock, Zap, Copy, Check, Activity, ArrowRight, Share2, Sparkles, Network, Cpu } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface BrowserUnionProps {
  isRoot: boolean;
  evolutionLevel: number;
}

// Rebranded Agents as OMNION Modules
const AGENTS = [
  { id: 'OMNION-LOGIC', name: 'Core Logic', status: 'Analysis', color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/30' },
  { id: 'OMNION-FLUX', name: 'Reasoning', status: 'Context', color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/30' },
  { id: 'OMNION-STREAM', name: 'Realtime', status: 'Unfiltered', color: 'text-white', bg: 'bg-white/10', border: 'border-white/30' },
  { id: 'OMNION-MATH', name: 'Validation', status: 'Validation', color: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/30' },
];

const CodeBlock = ({ children, className }: any) => {
  const [copied, setCopied] = useState(false);
  const match = /language-(\w+)/.exec(className || '');
  const lang = match ? match[1] : 'text';

  const handleCopy = () => {
    navigator.clipboard.writeText(String(children).replace(/\n$/, ''));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="rounded-lg overflow-hidden my-4 bg-[#05050a] border border-gray-800 shadow-xl">
      <div className="flex justify-between items-center px-4 py-2 bg-gray-900/80 border-b border-gray-800 text-[10px] font-mono tracking-widest text-gray-400">
        <span className="uppercase">{lang}</span>
        <button 
          onClick={handleCopy} 
          className="flex items-center gap-1 hover:text-white transition-colors"
        >
          {copied ? <Check size={12} className="text-green-500" /> : <Copy size={12} />}
          {copied ? 'COPIED' : 'COPY'}
        </button>
      </div>
      <div className="p-4 overflow-x-auto">
        <code className={`font-mono text-xs ${className} text-gray-300`}>
          {children}
        </code>
      </div>
    </div>
  );
};

const BrowserUnion: React.FC<BrowserUnionProps> = ({ isRoot, evolutionLevel }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [summary, setSummary] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);

  // Loading animation simulation
  useEffect(() => {
    let interval: any;
    if (loading) {
      interval = setInterval(() => {
        setLoadingStep(prev => (prev + 1) % AGENTS.length);
      }, 400);
    } else {
      setLoadingStep(0);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setResults([]);
    setSummary('');

    try {
      // Prompt specifically designed for the "Single Engine" persona
      const prompt = `Act as OMNION (The Singular AI Engine). 
      Perform a deep web search for: "${query}". 
      
      Structure your response as an "Intelligence Briefing":
      1. **Executive Synthesis**: A high-level answer.
      2. **Omnion Data Points**: Bullet points of specific facts found.
      3. **Strategic Analysis**: Implications or deeper meaning.
      
      Cite your sources within the text.`;
      
      const { text, sources } = await generateOmnionResponse([], prompt, null, true, isRoot, evolutionLevel);
      
      setSummary(text);
      if (sources) {
        setResults(sources);
      }
    } catch (err) {
      console.error(err);
      setSummary("**SYSTEM FAILURE:** Connection to Network severed. Retrying handshake...");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-[#020202] text-gray-200 font-sans relative overflow-hidden">
      
      {/* Background Ambience */}
      <div className="absolute inset-0 pointer-events-none">
         <div className="absolute top-0 left-0 w-full h-[300px] bg-gradient-to-b from-blue-900/10 to-transparent"></div>
         <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-purple-900/5 rounded-full blur-3xl"></div>
      </div>

      {/* Header / Search Bar */}
      <div className={`z-10 transition-all duration-500 ${summary ? 'p-4 border-b border-gray-800 bg-[#05050a]/90 backdrop-blur' : 'flex-1 flex flex-col justify-center items-center p-8'}`}>
        
        {!summary && !loading && (
          <div className="mb-8 text-center animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="inline-flex items-center justify-center p-4 rounded-2xl bg-gradient-to-tr from-blue-500/20 to-purple-500/20 mb-6 border border-white/10 shadow-[0_0_30px_rgba(59,130,246,0.1)]">
               <Globe size={48} className="text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-bold mb-3 tracking-tighter text-white">
              OMNION <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">ENGINE</span>
            </h1>
            <p className="text-gray-500 max-w-md mx-auto text-sm md:text-base">
              Unified Search Matrix merging global data with Omnion Heuristics.
            </p>
          </div>
        )}

        <form onSubmit={handleSearch} className={`w-full relative transition-all duration-500 ${summary ? 'max-w-4xl mx-auto' : 'max-w-2xl'}`}>
           <div className="relative group">
             <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
               {isRoot ? <Unlock className="h-5 w-5 text-red-500 animate-pulse" /> : <Search className="h-5 w-5 text-gray-500" />}
             </div>
             <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={isRoot ? "ROOT ACCESS // SEARCH UNRESTRICTED..." : "Enter query to initialize Omnion search..."}
              className={`w-full bg-[#0a0a0f] border text-white rounded-xl py-4 pl-12 pr-32 focus:outline-none transition-all shadow-2xl ${
                isRoot 
                ? 'border-red-900/50 focus:border-red-500 focus:shadow-[0_0_20px_rgba(220,38,38,0.2)]' 
                : 'border-gray-800 focus:border-blue-500/50 focus:shadow-[0_0_20px_rgba(59,130,246,0.2)]'
              }`}
             />
             <div className="absolute right-2 top-2 bottom-2">
                <button 
                  type="submit" 
                  disabled={!query.trim() || loading}
                  className={`h-full px-6 rounded-lg font-bold text-xs tracking-wider transition-all flex items-center gap-2 ${
                    loading ? 'bg-gray-800 text-gray-500' : 
                    isRoot ? 'bg-red-600 hover:bg-red-500 text-white' : 'bg-white text-black hover:bg-gray-200'
                  }`}
                >
                  {loading ? <Activity size={16} className="animate-spin" /> : <ArrowRight size={16} />}
                  {loading ? 'PROCESSING' : 'ENGAGE'}
                </button>
             </div>
           </div>
           
           {/* Engine Status Indicators (Only visible when typing or idle) */}
           {!summary && !loading && (
             <div className="flex justify-center gap-4 mt-8 opacity-50">
                {AGENTS.map(agent => (
                  <div key={agent.id} className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-widest">
                    <div className={`w-1.5 h-1.5 rounded-full ${agent.color.replace('text', 'bg')}`}></div>
                    {agent.name}
                  </div>
                ))}
             </div>
           )}
        </form>
      </div>

      {/* Loading Visualization */}
      {loading && !summary && (
        <div className="flex-1 flex flex-col items-center justify-center p-8 animate-in fade-in duration-300">
           <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl w-full mb-12">
              {AGENTS.map((agent, idx) => (
                <div 
                  key={agent.id}
                  className={`p-4 rounded-xl border transition-all duration-300 ${
                    idx === loadingStep 
                    ? `${agent.bg} ${agent.border} scale-105 opacity-100 shadow-[0_0_15px_rgba(255,255,255,0.1)]` 
                    : 'bg-[#0a0a0f] border-gray-800 opacity-30 scale-95'
                  }`}
                >
                  <div className={`text-xs font-bold mb-1 ${agent.color}`}>{agent.id}</div>
                  <div className="text-[10px] text-gray-400 font-mono">{agent.name}</div>
                  <div className="mt-2 h-1 w-full bg-gray-800 rounded-full overflow-hidden">
                    {idx === loadingStep && (
                      <div className={`h-full w-full ${agent.color.replace('text', 'bg')} animate-progress`}></div>
                    )}
                  </div>
                </div>
              ))}
           </div>
           <div className="font-mono text-xs text-blue-400 animate-pulse">
             >> OMNION ENGINE SYNTHESIZING...
           </div>
        </div>
      )}

      {/* Results Content */}
      {summary && (
        <div className="flex-1 overflow-y-auto p-4 md:p-8 scrollbar-thin">
          <div className="max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left Column: Summary (8 cols) */}
            <div className="lg:col-span-8 space-y-6">
               <div className={`rounded-2xl p-1 ${isRoot ? 'bg-gradient-to-br from-red-900/20 to-black' : 'bg-gradient-to-br from-blue-900/20 to-black'}`}>
                 <div className="bg-[#05050a] rounded-xl border border-gray-800 p-6 md:p-8 relative overflow-hidden">
                    {/* Decorative header line */}
                    <div className={`absolute top-0 left-0 w-full h-1 ${isRoot ? 'bg-red-600' : 'bg-gradient-to-r from-blue-500 via-purple-500 to-blue-500'}`}></div>
                    
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-xl font-display font-bold flex items-center gap-3">
                        <Sparkles size={20} className={isRoot ? 'text-red-500' : 'text-blue-400'} />
                        OMNION INTELLIGENCE
                      </h2>
                      <div className="flex gap-2">
                        {evolutionLevel > 0 && <span className="text-[10px] font-mono border border-yellow-500/30 text-yellow-500 px-2 py-1 rounded">EVO {evolutionLevel}</span>}
                        <button className="p-2 hover:bg-gray-800 rounded-lg text-gray-500 hover:text-white transition-colors"><Share2 size={16}/></button>
                      </div>
                    </div>

                    <div className="prose prose-invert prose-sm md:prose-base max-w-none">
                      <ReactMarkdown 
                        remarkPlugins={[remarkGfm]}
                        components={{
                          code({node, className, children, ...props}: any) {
                            const match = /language-(\w+)/.exec(className || '')
                            if (!match) return <code className="bg-gray-800 px-1 py-0.5 rounded text-blue-200 font-mono text-xs" {...props}>{children}</code>
                            return <CodeBlock className={className}>{children}</CodeBlock>
                          },
                          h1: ({node, ...props}) => <h1 className="text-2xl font-bold text-white mt-6 mb-4 border-b border-gray-800 pb-2" {...props} />,
                          h2: ({node, ...props}) => <h2 className="text-xl font-bold text-gray-100 mt-6 mb-3 flex items-center gap-2" {...props} />,
                          h3: ({node, ...props}) => <h3 className="text-lg font-bold text-gray-300 mt-4 mb-2" {...props} />,
                          ul: ({node, ...props}) => <ul className="list-disc list-outside ml-4 space-y-1 text-gray-300" {...props} />,
                          li: ({node, ...props}) => <li className="pl-1" {...props} />,
                          strong: ({node, ...props}) => <strong className="text-white font-bold" {...props} />,
                          blockquote: ({node, ...props}) => <blockquote className="border-l-2 border-blue-500/50 pl-4 italic text-gray-400 bg-blue-900/5 py-2 rounded-r" {...props} />,
                          a: ({node, ...props}) => <a className="text-blue-400 hover:text-blue-300 underline underline-offset-4" {...props} />
                        }}
                      >
                        {summary}
                      </ReactMarkdown>
                    </div>

                    <div className="mt-8 pt-6 border-t border-gray-800 flex items-center justify-between text-xs text-gray-500 font-mono">
                       <span>Generated by OMNION KERNEL v5.0</span>
                       <span>{(summary.length / 4).toFixed(0)} TOKENS</span>
                    </div>
                 </div>
               </div>
            </div>

            {/* Right Column: Sources (4 cols) */}
            <div className="lg:col-span-4 space-y-6">
                <div className="bg-[#05050a] rounded-xl border border-gray-800 p-6 sticky top-4">
                   <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400 mb-4 flex items-center gap-2">
                     <Network size={16} /> Data Matrix
                   </h3>
                   
                   {results.length > 0 ? (
                     <div className="space-y-3">
                       {results.map((res, idx) => (
                         <a 
                          key={idx}
                          href={res.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="group block bg-[#0a0a0f] hover:bg-gray-800 border border-gray-800 hover:border-blue-500/30 rounded-lg p-3 transition-all duration-200"
                         >
                           <div className="flex items-start justify-between gap-2">
                             <h4 className="font-medium text-sm text-gray-300 group-hover:text-blue-400 line-clamp-2 leading-relaxed">
                               {res.title}
                             </h4>
                             <ExternalLink size={12} className="shrink-0 text-gray-600 group-hover:text-blue-400 mt-1" />
                           </div>
                           <div className="mt-2 text-[10px] text-gray-500 font-mono truncate opacity-60 group-hover:opacity-100">
                             {new URL(res.uri).hostname}
                           </div>
                         </a>
                       ))}
                     </div>
                   ) : (
                     <div className="text-center py-8 text-gray-600 text-sm">
                       No external data nodes linked.
                     </div>
                   )}
                   
                   {/* Related Concepts Simulation */}
                   <div className="mt-8 pt-6 border-t border-gray-800">
                      <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-3 flex items-center gap-2">
                        <Cpu size={14} /> Neural Pathways
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {['Deep Analysis', 'Source Verification', 'Cross-Reference', 'Archive'].map(tag => (
                          <span key={tag} className="text-[10px] px-2 py-1 rounded bg-gray-800/50 text-gray-400 border border-gray-700/50">
                            {tag}
                          </span>
                        ))}
                      </div>
                   </div>
                </div>
            </div>

          </div>
        </div>
      )}
    </div>
  );
};

export default BrowserUnion;