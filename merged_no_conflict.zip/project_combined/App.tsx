import React, { useState, useEffect } from 'react';
import Terminal from './components/Terminal';
import BrowserUnion from './components/BrowserUnion';
import SystemPanel from './components/SystemPanel';
import Termux from './components/Termux';
import FileExplorer from './components/FileExplorer';
import FactorTreeHome from './components/FactorTreeHome';
import SensorSuite from './components/SensorSuite';
import VoiceAssistant from './components/VoiceAssistant';
import SettingsPanel from './components/SettingsPanel';
import { UserCredentials, AppMode, AppSettings } from './types';
import { ChevronLeft, Wifi, BatteryCharging, BrainCircuit } from 'lucide-react';

const App: React.FC = () => {
  const [mode, setMode] = useState<AppMode | 'HOME'>('HOME');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  
  // Settings State (Theme & Haptics)
  const [settings, setSettings] = useState<AppSettings>({
    theme: 'dark',
    haptics: {
      enabled: true,
      responseVibration: true
    }
  });

  const [user] = useState<UserCredentials>({
    email: 'root@omnion.ai',
    ip: '127.0.0.1',
    mac: '00:00:00:00:00:00',
    accessLevel: 'admin'
  });

  const [isRoot, setIsRoot] = useState(false);
  const [evolutionLevel, setEvolutionLevel] = useState(0);

  const handleGrantSudo = () => {
    setIsRoot(true);
  };

  const handleSelfUpgrade = () => {
    setEvolutionLevel(prev => prev + 1);
  };

  const handleInstallClick = () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then((choiceResult: any) => {
      if (choiceResult.outcome === 'accepted') {
        console.log('User accepted the install prompt');
      }
      setDeferredPrompt(null);
    });
  };

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => {
      clearInterval(timer);
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  // View Router
  const renderContent = () => {
    switch (mode) {
      case 'HOME':
        return (
          <FactorTreeHome 
            setMode={setMode} 
            evolutionLevel={evolutionLevel} 
            isRoot={isRoot} 
          />
        );
      case AppMode.TERMINAL:
        return <Terminal isRoot={isRoot} evolutionLevel={evolutionLevel} settings={settings} />;
      case AppMode.BROWSER:
        return <BrowserUnion isRoot={isRoot} evolutionLevel={evolutionLevel} />;
      case AppMode.SYSTEM:
        return (
          <SystemPanel 
            user={user}
            onGrantSudo={handleGrantSudo}
            isRoot={isRoot}
            evolutionLevel={evolutionLevel}
            onSelfUpgrade={handleSelfUpgrade}
            installPrompt={deferredPrompt}
            onInstall={handleInstallClick}
          />
        );
      case AppMode.TERMUX:
        return <Termux user={user} isRoot={isRoot} />;
      case AppMode.EXPLORER:
        return <FileExplorer isRoot={isRoot} />;
      case AppMode.SENSORS:
        return <SensorSuite isRoot={isRoot} />;
      case AppMode.ASSISTANT:
        return <VoiceAssistant setMode={setMode} isRoot={isRoot} />;
      case AppMode.SETTINGS:
        return <SettingsPanel settings={settings} setSettings={setSettings} setMode={setMode} />;
      default:
        return <div className="p-10 text-red-500">MODULE_NOT_FOUND</div>;
    }
  };

  // Status Bar visibility logic (Hide in Assistant/Settings for immersion)
  const showStatusBar = mode !== AppMode.ASSISTANT && mode !== AppMode.SETTINGS;
  
  // Theme Background Logic
  const getThemeClasses = () => {
    if (settings.theme === 'light') return 'bg-[#f5f5f7] text-gray-900';
    if (settings.theme === 'foryou') return 'bg-[#1a0b1a] text-pink-100'; // Custom "For You" Tint
    return 'bg-black text-gray-200'; // Dark/System Default
  };

  return (
    <div className={`flex flex-col h-screen w-screen overflow-hidden select-none relative transition-colors duration-500 ${getThemeClasses()}`}>
        
        {/* Global Status Bar */}
        {showStatusBar && (
            <div className={`h-8 backdrop-blur border-b flex items-center justify-between px-4 select-none z-50 shrink-0 absolute top-0 w-full ${settings.theme === 'light' ? 'bg-white/80 border-gray-200' : 'bg-black/80 border-white/10'}`}>
                <div className="flex items-center gap-2">
                    {mode !== 'HOME' ? (
                        <button 
                            onClick={() => setMode('HOME')}
                            className="flex items-center gap-1 text-[10px] bg-red-900/20 text-red-400 px-2 py-0.5 rounded border border-red-500/30 hover:bg-red-900/40 transition-colors"
                        >
                            <ChevronLeft size={12} /> CORE MAP
                        </button>
                    ) : (
                        <div className="text-[10px] font-mono text-gray-500 flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                            <span>SYSTEM ONLINE</span>
                        </div>
                    )}
                    
                    {mode !== 'HOME' && (
                        <div className={`text-[10px] font-mono flex items-center gap-2 ml-2 border-l pl-2 ${settings.theme === 'light' ? 'border-gray-300 text-gray-500' : 'border-white/10 text-gray-500'}`}>
                            <span className="font-bold text-red-500 flex items-center gap-1">
                                <BrainCircuit size={10} /> OMNION
                            </span>
                            <span className="hidden md:inline opacity-70">/ {mode}</span>
                        </div>
                    )}
                </div>
                
                <div className="flex items-center gap-3 text-xs opacity-70 font-medium">
                    <div className="flex items-center gap-1">
                        <Wifi size={12} className={Math.random() > 0.5 ? 'text-blue-400' : 'text-gray-500'} />
                        <span className="text-[10px] font-mono hidden sm:inline">NET_OK</span>
                    </div>
                    <div className="flex items-center gap-1">
                        <BatteryCharging size={12} className="text-green-400" />
                        <span className="text-[10px] font-mono hidden sm:inline">100%</span>
                    </div>
                    <div className="w-px h-3 bg-current opacity-20 mx-1"></div>
                    <span className="font-mono text-[10px] tracking-wider">
                        {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                </div>
            </div>
        )}

        {/* Main Content Area */}
        <div className={`flex-1 w-full h-full relative ${showStatusBar ? 'pt-8' : ''}`}>
            {renderContent()}
        </div>

    </div>
  );
};

export default App;