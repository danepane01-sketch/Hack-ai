# filebrowser version

Print the version number

```
filebrowser version [flags]
```

## Options

```
  -h, --help   help for version
```

## Options inherited from parent commands

```
  -c, --config string     config file path
  -d, --database string   database path (default "./filebrowser.db")
```

## See Also

* [filebrowser](filebrowser.md)	 - A stylish web-based file browser

