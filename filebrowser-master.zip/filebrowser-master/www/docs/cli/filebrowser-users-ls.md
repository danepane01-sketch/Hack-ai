# filebrowser users ls

List all users.

```
filebrowser users ls [flags]
```

## Options

```
  -h, --help   help for ls
```

## Options inherited from parent commands

```
  -c, --config string     config file path
  -d, --database string   database path (default "./filebrowser.db")
```

## See Also

* [filebrowser users](filebrowser-users.md)	 - Users management utility

