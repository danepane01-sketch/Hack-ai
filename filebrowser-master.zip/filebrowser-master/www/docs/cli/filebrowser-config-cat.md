# filebrowser config cat

Prints the configuration

## Synopsis

Prints the configuration.

```
filebrowser config cat [flags]
```

## Options

```
  -h, --help   help for cat
```

## Options inherited from parent commands

```
  -c, --config string     config file path
  -d, --database string   database path (default "./filebrowser.db")
```

## See Also

* [filebrowser config](filebrowser-config.md)	 - Configuration management utility

