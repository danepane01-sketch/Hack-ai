import React, { useState, useEffect, useRef } from 'react';
import { Compass, Navigation, Thermometer, LocateFixed, Rotate3D, Activity, Wifi, Lock, MapPin, Gauge } from 'lucide-react';

interface SensorSuiteProps {
  isRoot: boolean;
}

const SensorSuite: React.FC<SensorSuiteProps> = ({ isRoot }) => {
  const [coords, setCoords] = useState<GeolocationCoordinates | null>(null);
  const [orientation, setOrientation] = useState<{ alpha: number, beta: number, gamma: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [thermal, setThermal] = useState<number>(36.5); // Simulated baseline
  const [isCalibrating, setIsCalibrating] = useState(true);
  
  // References for animation frames
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // 1. GPS Initialization
  useEffect(() => {
    if (!navigator.geolocation) {
      setError("GPS Hardware not detected.");
      return;
    }

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        setCoords(pos.coords);
        setIsCalibrating(false);
      },
      (err) => {
        setError(`GPS Signal Lost: ${err.message}`);
        setIsCalibrating(false);
      },
      { enableHighAccuracy: true, maximumAge: 0, timeout: 5000 }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, []);

  // 2. Gyroscope / Compass Initialization
  useEffect(() => {
    const handleOrientation = (event: DeviceOrientationEvent) => {
      setOrientation({
        alpha: event.alpha || 0, // Compass direction (0-360)
        beta: event.beta || 0,   // Front/Back tilt (-180 to 180)
        gamma: event.gamma || 0  // Left/Right tilt (-90 to 90)
      });
    };

    // iOS 13+ Permissions
    const requestAccess = async () => {
      if (typeof (DeviceOrientationEvent as any).requestPermission === 'function') {
        try {
          const response = await (DeviceOrientationEvent as any).requestPermission();
          if (response === 'granted') {
            window.addEventListener('deviceorientation', handleOrientation);
          } else {
            setError("Sensor Access Denied.");
          }
        } catch (e) {
          setError("Sensor API Error.");
        }
      } else {
        window.addEventListener('deviceorientation', handleOrientation);
      }
    };

    requestAccess();

    return () => window.removeEventListener('deviceorientation', handleOrientation);
  }, []);

  // 3. Thermal & Environment Estimator (Simulated)
  // Since Browsers don't give ambient temp, we calculate a "Device Stress" temp simulation
  // combined with a mock "Environmental Scan"
  useEffect(() => {
    const interval = setInterval(() => {
        setThermal(prev => {
            const movementHeat = orientation ? (Math.abs(orientation.beta) + Math.abs(orientation.gamma)) / 20 : 0;
            const base = 35;
            const fluctuation = Math.random() * 0.5;
            return parseFloat((base + movementHeat + fluctuation).toFixed(1));
        });
    }, 2000);
    return () => clearInterval(interval);
  }, [orientation]);

  // Visual Components
  
  // Compass Ring
  const CompassVisual = () => {
    const heading = orientation?.alpha || 0;
    return (
        <div className="relative w-48 h-48 rounded-full border-2 border-gray-800 flex items-center justify-center bg-[#0a0a0f] shadow-[0_0_30px_rgba(0,0,0,0.5)]">
            {/* Outer Static Ring */}
            <div className="absolute inset-0 rounded-full border border-dashed border-gray-700 opacity-50"></div>
            <div className="absolute top-0 text-[10px] font-bold text-red-500">N</div>
            <div className="absolute bottom-0 text-[10px] font-bold text-gray-500">S</div>
            <div className="absolute left-0 text-[10px] font-bold text-gray-500">W</div>
            <div className="absolute right-0 text-[10px] font-bold text-gray-500">E</div>

            {/* Rotating Dial */}
            <div 
                className="w-full h-full rounded-full transition-transform duration-300 ease-out"
                style={{ transform: `rotate(${-heading}deg)` }}
            >
                <div className="absolute top-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-b-[12px] border-b-red-600"></div>
                <div className="absolute inset-4 rounded-full border border-gray-800"></div>
                
                {/* Degree Ticks */}
                {[0, 45, 90, 135, 180, 225, 270, 315].map(deg => (
                    <div 
                        key={deg} 
                        className="absolute top-0 left-1/2 -translate-x-1/2 h-full w-0.5" 
                        style={{ transform: `rotate(${deg}deg)` }}
                    >
                        <div className="w-full h-2 bg-gray-600"></div>
                    </div>
                ))}
            </div>

            {/* Center Readout */}
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/50 backdrop-blur-sm rounded-full w-20 h-20 m-auto border border-gray-700">
                <span className="text-xl font-display font-bold text-white">{heading.toFixed(0)}°</span>
                <span className="text-[9px] text-gray-400">MAG_HDG</span>
            </div>
        </div>
    );
  };

  // Artificial Horizon
  const ArtificialHorizon = () => {
    const pitch = orientation?.beta || 0; // Up/Down
    const roll = orientation?.gamma || 0; // Tilt
    
    return (
        <div className="relative w-full h-32 bg-gray-900 overflow-hidden rounded-xl border border-gray-700 shadow-inner">
            {/* Sky/Ground */}
            <div 
                className="absolute w-[200%] h-[200%] top-[-50%] left-[-50%] transition-transform duration-100 ease-linear"
                style={{ 
                    background: 'linear-gradient(to bottom, #0ea5e9 50%, #78350f 50%)',
                    transform: `rotate(${roll}deg) translateY(${pitch * 2}px)` 
                }}
            >
                <div className="absolute top-1/2 w-full h-0.5 bg-white shadow-[0_0_10px_white]"></div>
            </div>

            {/* HUD Overlay */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                 <div className="w-24 h-0.5 bg-red-500/80"></div> {/* Plane Center */}
                 <div className="absolute w-2 h-2 rounded-full border border-red-500"></div>
            </div>
            
            <div className="absolute top-2 left-2 bg-black/50 px-2 py-1 rounded text-[10px] font-mono">
                PITCH: {pitch.toFixed(1)}°
            </div>
            <div className="absolute top-2 right-2 bg-black/50 px-2 py-1 rounded text-[10px] font-mono">
                ROLL: {roll.toFixed(1)}°
            </div>
        </div>
    );
  };

  return (
    <div className="h-full bg-black text-gray-200 overflow-y-auto p-4 md:p-8 relative">
        {/* Background Grid */}
        <div className="absolute inset-0 bg-grid opacity-20 pointer-events-none"></div>

        <div className="max-w-6xl mx-auto space-y-8 relative z-10">
            
            {/* Header */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-gray-800 pb-4 gap-4">
                <div>
                    <h1 className="text-3xl font-display font-bold text-white flex items-center gap-3">
                        <Activity className="text-orange-500 animate-pulse" />
                        SENSOR ARRAY
                    </h1>
                    <p className="text-xs text-gray-500 font-mono tracking-widest mt-1">
                        OMNION SPATIAL AWARENESS ENGINE
                    </p>
                </div>
                <div className="flex gap-2">
                     <div className="flex items-center gap-2 bg-gray-900 px-3 py-1.5 rounded-full border border-gray-700 text-xs font-mono">
                         <div className={`w-2 h-2 rounded-full ${coords ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></div>
                         GPS: {coords ? 'LOCKED' : 'SEARCHING'}
                     </div>
                     <div className="flex items-center gap-2 bg-gray-900 px-3 py-1.5 rounded-full border border-gray-700 text-xs font-mono">
                         <div className={`w-2 h-2 rounded-full ${orientation ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                         GYRO: {orientation ? 'ACTIVE' : 'STANDBY'}
                     </div>
                </div>
            </div>

            {error && (
                <div className="bg-red-900/20 border border-red-500/50 p-4 rounded-xl text-red-400 text-sm font-bold flex items-center gap-3">
                    <Lock size={16} />
                    {error}
                    <button 
                        onClick={() => window.location.reload()} 
                        className="ml-auto bg-red-900/40 px-3 py-1 rounded hover:bg-red-900/60"
                    >
                        RETRY
                    </button>
                </div>
            )}

            {/* Main Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

                {/* COLUMN 1: NAVIGATION (Compass & GPS) */}
                <div className="space-y-6">
                    <div className="bg-[#0f111a] border border-gray-800 rounded-2xl p-6 flex flex-col items-center relative overflow-hidden">
                        <div className="absolute top-2 left-3 text-xs font-bold text-gray-500 flex items-center gap-1">
                            <Compass size={14} /> MAGNETIC HEADING
                        </div>
                        <div className="my-4">
                            <CompassVisual />
                        </div>
                        <div className="w-full grid grid-cols-3 gap-2 text-center text-[10px] font-mono text-gray-400 mt-2">
                            <div className="bg-black/40 p-1 rounded border border-gray-800">
                                <span className="block text-gray-600">X-AXIS</span>
                                {orientation?.beta.toFixed(0)}°
                            </div>
                            <div className="bg-black/40 p-1 rounded border border-gray-800">
                                <span className="block text-gray-600">Y-AXIS</span>
                                {orientation?.gamma.toFixed(0)}°
                            </div>
                            <div className="bg-black/40 p-1 rounded border border-gray-800">
                                <span className="block text-gray-600">Z-AXIS</span>
                                {orientation?.alpha.toFixed(0)}°
                            </div>
                        </div>
                    </div>

                    <div className="bg-[#0f111a] border border-gray-800 rounded-2xl p-6 relative">
                        <h3 className="text-xs font-bold text-gray-500 flex items-center gap-2 mb-4">
                            <MapPin size={14} /> GEOSPATIAL DATA
                        </h3>
                        <div className="space-y-4 font-mono text-sm">
                            <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                                <span className="text-gray-500">LATITUDE</span>
                                <span className="text-white text-lg">{coords?.latitude.toFixed(6) || '---'}</span>
                            </div>
                            <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                                <span className="text-gray-500">LONGITUDE</span>
                                <span className="text-white text-lg">{coords?.longitude.toFixed(6) || '---'}</span>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-gray-500">ACCURACY</span>
                                <span className="text-green-400">±{coords?.accuracy.toFixed(0) || '0'}m</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* COLUMN 2: ORIENTATION (Horizon & Speed) */}
                <div className="space-y-6">
                    <div className="bg-[#0f111a] border border-gray-800 rounded-2xl p-6 h-full flex flex-col">
                        <h3 className="text-xs font-bold text-gray-500 flex items-center gap-2 mb-4">
                            <Rotate3D size={14} /> GYRO-HORIZON
                        </h3>
                        <div className="flex-1 flex flex-col justify-center gap-6">
                            <ArtificialHorizon />
                            
                            <div className="grid grid-cols-2 gap-4">
                                <div className="bg-black/40 rounded-xl p-4 border border-gray-800 flex flex-col items-center">
                                    <span className="text-[10px] text-gray-500 mb-1">ALTITUDE</span>
                                    <div className="text-2xl font-display text-blue-400">
                                        {coords?.altitude ? coords.altitude.toFixed(0) : '0'}
                                        <span className="text-xs text-gray-600 ml-1">m</span>
                                    </div>
                                </div>
                                <div className="bg-black/40 rounded-xl p-4 border border-gray-800 flex flex-col items-center">
                                    <span className="text-[10px] text-gray-500 mb-1">VELOCITY</span>
                                    <div className="text-2xl font-display text-orange-400">
                                        {coords?.speed ? (coords.speed * 3.6).toFixed(1) : '0'}
                                        <span className="text-xs text-gray-600 ml-1">km/h</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* COLUMN 3: ENVIRONMENT (Thermal & Signal) */}
                <div className="space-y-6">
                     <div className="bg-[#0f111a] border border-gray-800 rounded-2xl p-6 relative overflow-hidden">
                        <div className={`absolute top-0 right-0 p-24 bg-red-600/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none`}></div>
                        
                        <h3 className="text-xs font-bold text-gray-500 flex items-center gap-2 mb-4">
                            <Thermometer size={14} /> THERMAL & ATMOSPHERE
                        </h3>

                        <div className="flex items-end gap-2 mb-2">
                             <span className="text-5xl font-display font-bold text-white">{thermal.toFixed(1)}</span>
                             <span className="text-xl text-gray-500 mb-2">°C</span>
                        </div>
                        <div className="w-full h-2 bg-gray-800 rounded-full overflow-hidden mb-4">
                            <div 
                                className="h-full bg-gradient-to-r from-blue-500 via-yellow-500 to-red-500 transition-all duration-1000" 
                                style={{ width: `${(thermal / 60) * 100}%` }}
                            ></div>
                        </div>
                        <p className="text-[10px] text-gray-500 italic">
                            *Estimated ambient temperature based on device workload and geospatial location data via Omnion Inference.
                        </p>
                     </div>

                     <div className="bg-[#0f111a] border border-gray-800 rounded-2xl p-6">
                        <h3 className="text-xs font-bold text-gray-500 flex items-center gap-2 mb-4">
                            <Wifi size={14} /> SIGNAL TRIANGULATION
                        </h3>
                        
                        <div className="space-y-3">
                             {['GPS_SAT_A12', 'GPS_SAT_B04', 'GLONASS_V9'].map((sat, i) => (
                                 <div key={i} className="flex justify-between items-center text-xs">
                                     <span className="font-mono text-gray-400">{sat}</span>
                                     <div className="flex gap-1">
                                         {[...Array(5)].map((_, j) => (
                                             <div key={j} className={`w-1 h-3 rounded-full ${j < (4-i) ? 'bg-green-500' : 'bg-gray-800'}`}></div>
                                         ))}
                                     </div>
                                 </div>
                             ))}
                        </div>
                     </div>

                     {/* Sync Button */}
                     <button className="w-full py-4 bg-gray-900 border border-gray-700 rounded-xl text-xs font-bold tracking-widest hover:bg-gray-800 hover:text-white transition-all flex items-center justify-center gap-2 group">
                         <LocateFixed size={16} className="group-hover:animate-ping" />
                         SYNC TO OMNION CORE
                     </button>
                </div>

            </div>
        </div>
    </div>
  );
};

export default SensorSuite;