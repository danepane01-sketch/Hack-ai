import React, { useState, useRef, useEffect } from 'react';
import { Message, GroundingSource, Attachment, AppSettings } from '../types';
import { generateOmnionStream } from '../services/omnionService';
import { Send, Globe, Cpu, AlertTriangle, Paperclip, X, Sparkles, Copy, Check, Bot, User, Mic, MicOff, Heart, Volume2, ThumbsUp, VolumeX, Trash2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface TerminalProps {
  isRoot: boolean;
  evolutionLevel: number;
  settings: AppSettings;
}

const QUICK_PROMPTS = [
  "Buatkan rencana belajar efektif.",
  "Jelaskan teori relativitas.",
  "Tulis puisi tentang hujan.",
  "Analisis sentimen pasar hari ini.",
];

// --- COMPONENTS ---

const CodeBlock = ({ children, className }: any) => {
  const [copied, setCopied] = useState(false);
  const match = /language-(\w+)/.exec(className || '');
  const lang = match ? match[1] : 'text';

  const handleCopy = () => {
    navigator.clipboard.writeText(String(children).replace(/\n$/, ''));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!match) {
    return <code className={className}>{children}</code>;
  }

  return (
    <div className="rounded-lg overflow-hidden my-4 bg-[#0a0a0a] border border-[#333] select-text">
      <div className="flex justify-between items-center px-4 py-2 bg-[#111] border-b border-[#333] text-xs text-gray-400">
        <span className="uppercase font-mono font-bold tracking-wider">{lang}</span>
        <button 
          onClick={handleCopy} 
          className="flex items-center gap-1 hover:text-white transition-colors"
        >
          {copied ? <Check size={14} className="text-white" /> : <Copy size={14} />}
          {copied ? 'COPIED' : 'COPY'}
        </button>
      </div>
      <div className="p-4 overflow-x-auto">
        <code className={`font-mono text-sm ${className} text-gray-300`}>
          {children}
        </code>
      </div>
    </div>
  );
};

const Terminal: React.FC<TerminalProps> = ({ isRoot, evolutionLevel, settings }) => {
  const [input, setInput] = useState('');
  
  // RESTORED: Specific Boot Message from Screenshot 1
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'system',
      content: 'Omnion v6.0 (Apex Linguistic Core) Online. My reasoning is absolute.',
      timestamp: new Date()
    }
  ]);
  
  const [isLoading, setIsLoading] = useState(false);
  const [searchMode, setSearchMode] = useState(false);
  const [attachment, setAttachment] = useState<Attachment | null>(null);
  const [showPrompts, setShowPrompts] = useState(true);
  
  // Voice State
  const [autoRead, setAutoRead] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, attachment, isSpeaking]);

  // Haptic Helper
  const triggerHaptic = () => {
    if (settings.haptics.enabled && navigator.vibrate) {
        navigator.vibrate(10);
    }
  };

  const clearChat = () => {
    if (confirm("Hapus semua riwayat percakapan?")) {
        triggerHaptic();
        setMessages([{
            role: 'system',
            content: 'Omnion v6.0 (Apex Linguistic Core) Online. My reasoning is absolute.',
            timestamp: new Date()
        }]);
        setShowPrompts(true);
    }
  };

  // Voice Recording Logic
  const startRecording = async () => {
    try {
      triggerHaptic();
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      const audioChunks: BlobPart[] = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunks.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/mp3' });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = () => {
             const base64data = reader.result as string;
             setAttachment({
                 name: "voice_sample.mp3",
                 mimeType: "audio/mp3",
                 data: base64data
             });
             setMessages(prev => [...prev, {
                 role: 'system',
                 content: '🎤 Audio direkam. Menganalisis pola suara...',
                 timestamp: new Date()
             }]);
        };
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Mic Error:", err);
      alert("Izin mikrofon diperlukan.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const speakResponse = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    const cleanText = text.replace(/[*#`]/g, '').trim();
    if (!cleanText) return;

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(cleanText);
    const voices = window.speechSynthesis.getVoices();
    const idVoice = voices.find(v => v.lang.includes('id-ID'));
    const enVoice = voices.find(v => v.lang.includes('en-US'));
    if (idVoice) utterance.voice = idVoice;
    else if (enVoice) utterance.voice = enVoice;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  const handleLike = (index: number) => {
    triggerHaptic();
    setMessages(prev => prev.map((msg, i) => {
      if (i === index) {
        return { ...msg, liked: !msg.liked };
      }
      return msg;
    }));
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAttachment({
          name: file.name,
          mimeType: file.type,
          data: reader.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const removeAttachment = () => {
    setAttachment(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!input.trim() && !attachment) || isLoading) return;

    triggerHaptic();

    const currentInput = input;
    const currentAttachment = attachment;

    const userMsg: Message = {
      role: 'user',
      content: currentInput,
      timestamp: new Date(),
      attachment: currentAttachment || undefined
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setAttachment(null);
    setShowPrompts(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
    
    setIsLoading(true);

    // Initial Haptic for response start
    if (settings.haptics.enabled && settings.haptics.responseVibration && navigator.vibrate) {
        navigator.vibrate(20); 
    }

    try {
      const placeholderMsg: Message = {
        role: 'model',
        content: '',
        timestamp: new Date(),
        groundingSources: []
      };
      
      setMessages(prev => [...prev, placeholderMsg]);

      const stream = generateOmnionStream(messages, currentInput, currentAttachment, searchMode, isRoot, evolutionLevel);
      
      let accumulatedText = '';
      let accumulatedSources: GroundingSource[] = [];

      for await (const chunk of stream) {
        if (chunk.text) {
          accumulatedText += chunk.text;
        }
        if (chunk.sources && chunk.sources.length > 0) {
          accumulatedSources = [...accumulatedSources, ...chunk.sources];
        }

        setMessages(prev => {
          const newMessages = [...prev];
          const lastIndex = newMessages.length - 1;
          
          if (lastIndex >= 0) {
            newMessages[lastIndex] = {
              ...newMessages[lastIndex],
              content: accumulatedText,
              groundingSources: accumulatedSources.length > 0 ? accumulatedSources : undefined
            };
          }
          return newMessages;
        });
      }

      // Success Haptic
      if (settings.haptics.enabled && settings.haptics.responseVibration && navigator.vibrate) {
        navigator.vibrate(15);
      }

      if (!searchMode && accumulatedText && autoRead) {
          speakResponse(accumulatedText);
      }

    } catch (error) {
      setMessages(prev => [...prev, {
        role: 'system',
        content: 'Error: Koneksi terputus.',
        timestamp: new Date(),
        isError: true
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const insertPrompt = (prompt: string) => {
    triggerHaptic();
    setInput(prompt);
    setShowPrompts(false);
  };

  const renderAttachmentPreview = (att: Attachment, isMessage: boolean = false) => {
    if (att.mimeType.startsWith('image/')) {
      return (
        <img 
          src={att.data} 
          alt="Upload" 
          className={`rounded-lg border border-[#333] object-contain ${isMessage ? 'max-w-full max-h-64' : 'h-10 w-10'}`}
        />
      );
    }
    return (
      <div className={`flex items-center gap-2 bg-[#222] rounded p-2 border border-[#333] ${isMessage ? '' : 'h-10'}`}>
        <Paperclip size={16} className="text-gray-400" />
        <span className="text-xs text-gray-300 truncate max-w-[150px]">{att.name}</span>
      </div>
    );
  };

  return (
    <div className={`h-full flex flex-col font-sans relative overflow-hidden ${settings.theme === 'light' ? 'bg-[#f5f5f7] text-gray-900' : 'bg-[#020005] text-gray-200'}`}>
      
      {/* Top Controls Overlay */}
      <div className="absolute top-0 right-0 p-4 z-20 flex gap-2">
         <button 
           onClick={clearChat}
           className={`p-2 backdrop-blur rounded-full transition-all border ${settings.theme === 'light' ? 'bg-white/50 border-gray-200 text-gray-600 hover:text-red-500' : 'bg-black/50 border-transparent text-gray-500 hover:text-red-500 hover:border-red-500/30'}`}
           title="Hapus Percakapan"
         >
            <Trash2 size={16} />
         </button>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-thin scrollbar-thumb-gray-800 scrollbar-track-transparent">
        {messages.map((msg, idx) => {
            let displayContent = msg.content;
            
            if (msg.role === 'model') {
                displayContent = displayContent.trim();
                if (!displayContent && msg.content.length > 0) {
                     return (
                         <div key={idx} className="flex gap-4 animate-in fade-in slide-in-from-bottom-2">
                             <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${settings.theme === 'light' ? 'bg-gray-200' : 'bg-gray-800'}`}>
                                <Bot size={16} className="text-blue-500 animate-spin" />
                             </div>
                             <div className="flex flex-col max-w-[75%] items-start">
                                 <div className={`rounded-xl px-4 py-3 border text-xs italic animate-pulse ${settings.theme === 'light' ? 'bg-white border-gray-200 text-gray-500' : 'bg-[#0a0508] border-gray-800 text-gray-400'}`}>
                                     Omnion sedang berpikir...
                                 </div>
                             </div>
                         </div>
                     );
                }
                if (!displayContent) return null;
            }

            // EXACT SCREENSHOT 1 STYLING FOR SYSTEM MESSAGE
            if (msg.role === 'system') {
                return (
                    <div key={idx} className="flex gap-4 animate-in fade-in slide-in-from-bottom-2">
                         <div className="w-8 h-8 rounded-xl bg-red-900/10 border border-red-500/30 flex items-center justify-center shrink-0">
                             <Heart size={14} className="text-red-500" />
                         </div>
                         <div className="flex flex-col max-w-full items-start">
                            <div className="text-[10px] text-gray-500 mb-1 font-mono uppercase tracking-wider ml-1">
                                SYSTEM • {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </div>
                            <div className="rounded-xl px-5 py-3 border border-red-900/50 bg-[#1a0505] text-red-100 font-mono text-xs shadow-[0_0_15px_rgba(220,38,38,0.1)] flex items-center gap-3">
                                <span>{msg.content}</span>
                                <Heart size={12} className="text-gray-500 fill-gray-500" />
                            </div>
                         </div>
                    </div>
                );
            }

            return (
              <div 
                key={idx} 
                className={`flex gap-4 animate-in fade-in slide-in-from-bottom-2 duration-300 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
              >
                {/* Avatar */}
                <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                  msg.role === 'user' ? (settings.theme === 'light' ? 'bg-gray-200' : 'bg-[#1a1a1a]') : 
                  (settings.theme === 'light' ? 'bg-blue-100' : 'bg-blue-900/20')
                }`}>
                  {msg.role === 'user' ? <User size={16} className={settings.theme === 'light' ? 'text-gray-600' : 'text-gray-400'} /> :
                   <Bot size={16} className="text-blue-500" />
                  }
                </div>

                {/* Content Bubble */}
                <div className={`flex flex-col max-w-[85%] md:max-w-[75%] ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                  
                  {msg.attachment && (
                    <div className="mb-2">
                      {renderAttachmentPreview(msg.attachment, true)}
                    </div>
                  )}

                  <div className={`rounded-2xl px-5 py-3 border relative overflow-hidden shadow-sm ${
                    msg.role === 'user' 
                      ? (settings.theme === 'light' ? 'bg-white border-gray-200 text-gray-800' : 'bg-[#1a1a1a] border-[#333] text-gray-100') + ' rounded-tr-sm' 
                      : (settings.theme === 'light' ? 'bg-white border-gray-200 text-gray-800' : 'bg-[#0a0a0f] border-gray-800 text-gray-200') + ' rounded-tl-sm'
                  }`}>
                    {msg.isError && (
                      <div className="flex items-center gap-2 text-red-400 mb-2 border-b border-red-900/30 pb-2">
                        <AlertTriangle size={14} />
                        <span className="text-xs font-bold uppercase">System Error</span>
                      </div>
                    )}
                    
                    <div className="prose prose-invert prose-sm max-w-none">
                      <ReactMarkdown 
                        remarkPlugins={[remarkGfm]}
                        components={{
                          code({node, className, children, ...props}: any) {
                            const match = /language-(\w+)/.exec(className || '')
                            if (!match) return <code className="bg-white/10 px-1 py-0.5 rounded text-blue-200 font-mono text-xs" {...props}>{children}</code>
                            return <CodeBlock className={className}>{children}</CodeBlock>
                          },
                          p: ({node, ...props}) => <p className={`mb-2 last:mb-0 leading-relaxed ${settings.theme === 'light' ? 'text-gray-800' : 'text-gray-200'}`} {...props} />,
                          strong: ({node, ...props}) => <strong className={settings.theme === 'light' ? 'text-black' : 'text-white'} {...props} />,
                        }}
                      >
                         {displayContent}
                      </ReactMarkdown>
                    </div>

                    {/* Action Buttons */}
                    {msg.role === 'model' && (
                        <div className="mt-3 pt-2 border-t border-black/5 dark:border-white/5 flex items-center justify-end gap-3 opacity-60 hover:opacity-100 transition-opacity">
                            <button onClick={() => speakResponse(displayContent)} className="hover:text-blue-500"><Volume2 size={14} /></button>
                            <button onClick={() => navigator.clipboard.writeText(displayContent)} className="hover:text-blue-500"><Copy size={14} /></button>
                            <button onClick={() => handleLike(idx)} className={msg.liked ? 'text-blue-500' : 'hover:text-blue-500'}><ThumbsUp size={14} fill={msg.liked ? "currentColor" : "none"} /></button>
                        </div>
                    )}

                  </div>
                </div>
              </div>
            );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className={`p-4 backdrop-blur border-t ${settings.theme === 'light' ? 'bg-white/90 border-gray-200' : 'bg-black/90 border-[#222]'}`}>
        
        {/* Quick Prompts */}
        {showPrompts && messages.length < 3 && (
          <div className="flex gap-2 mb-4 overflow-x-auto pb-2 scrollbar-hide">
            {QUICK_PROMPTS.map((prompt, i) => (
              <button 
                key={i}
                onClick={() => insertPrompt(prompt)}
                className={`border px-3 py-1.5 rounded-full text-xs whitespace-nowrap transition-colors ${settings.theme === 'light' ? 'bg-gray-100 border-gray-300 text-gray-700 hover:bg-gray-200' : 'bg-[#111] border-[#333] text-gray-400 hover:bg-[#222]'}`}
              >
                {prompt}
              </button>
            ))}
          </div>
        )}

        <form onSubmit={handleSubmit} className="relative max-w-4xl mx-auto flex gap-3 items-end">
          <button 
            type="button" 
            onClick={() => setShowPrompts(!showPrompts)}
            className="p-3 text-gray-500 hover:text-blue-500 transition-colors mb-1"
          >
            <Sparkles size={20} />
          </button>

          <div className={`relative flex-1 border rounded-2xl focus-within:ring-2 focus-within:ring-blue-500/50 transition-all ${settings.theme === 'light' ? 'bg-gray-100 border-gray-300' : 'bg-[#111] border-[#333]'}`}>
            {attachment && (
               <div className="px-3 pt-3 pb-0 flex items-center justify-between">
                   {renderAttachmentPreview(attachment)}
                   <button type="button" onClick={removeAttachment} className="text-gray-500 hover:text-red-500"><X size={14}/></button>
               </div>
            )}
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ketik pesan untuk Omnion..."
              className={`w-full bg-transparent border-none focus:ring-0 text-sm p-4 ${settings.theme === 'light' ? 'text-black placeholder-gray-500' : 'text-gray-200 placeholder-gray-600'}`}
              disabled={isLoading}
            />
            {/* Mic / Upload Buttons inside input */}
            <div className="absolute right-2 bottom-2 flex items-center gap-1">
                 <input 
                    type="file" 
                    ref={fileInputRef}
                    className="hidden" 
                    onChange={handleFileSelect}
                 />
                 
                 <button 
                    type="button"
                    onClick={() => setAutoRead(!autoRead)}
                    className={`p-2 transition-colors rounded-full ${autoRead ? 'text-blue-500 bg-blue-500/10' : 'text-gray-500 hover:text-blue-500'}`}
                 >
                    {autoRead ? <Volume2 size={18} /> : <VolumeX size={18} />}
                 </button>

                 <button 
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="p-2 text-gray-500 hover:text-blue-500 transition-colors rounded-full"
                 >
                    <Paperclip size={18} />
                 </button>
                 <button 
                    type="button"
                    onMouseDown={startRecording}
                    onMouseUp={stopRecording}
                    onTouchStart={startRecording}
                    onTouchEnd={stopRecording}
                    className={`p-2 transition-colors rounded-full ${isRecording ? 'text-red-500 bg-red-500/10 animate-pulse' : 'text-gray-500 hover:text-blue-500'}`}
                 >
                    {isRecording ? <MicOff size={18} /> : <Mic size={18} />}
                 </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={(!input.trim() && !attachment) || isLoading}
            className={`p-4 rounded-2xl flex items-center justify-center transition-all duration-300 ${
              input.trim() || attachment 
                ? 'bg-blue-600 text-white shadow-lg hover:scale-105' 
                : (settings.theme === 'light' ? 'bg-gray-200 text-gray-400' : 'bg-[#1a1a1a] text-gray-600') + ' cursor-not-allowed'
            }`}
          >
             {isLoading ? <Cpu size={20} className="animate-spin" /> : <Send size={20} />}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Terminal;