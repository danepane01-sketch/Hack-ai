import React, { useState, useEffect, useRef } from 'react';
import { UserCredentials } from '../types';
import { TerminalSquare, XCircle } from 'lucide-react';

interface TermuxProps {
  user: UserCredentials;
  isRoot: boolean;
}

const Termux: React.FC<TermuxProps> = ({ user, isRoot }) => {
  const [history, setHistory] = useState<string[]>([]);
  const [input, setInput] = useState('');
  const [cwd, setCwd] = useState('~');
  const inputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Initial banner
  useEffect(() => {
    setHistory([
      "Welcome to Termux!",
      "",
      "Wiki:            https://wiki.termux.com",
      "Community forum: https://termux.com/community",
      "Gitter chat:     https://gitter.im/termux/termux",
      "IRC channel:     #termux on freenode",
      "",
      "Working with packages:",
      "",
      " * Search packages:   pkg search <query>",
      " * Install a package: pkg install <package>",
      " * Upgrade packages:  pkg upgrade",
      "",
      "Subscribing to additional repositories:",
      "",
      " * Root:     pkg install root-repo",
      " * X11:      pkg install x11-repo",
      "",
      "Report issues at https://termux.com/issues",
      "",
      "Type 'python loading_animation.py' to test OMNION visualizer.",
      "",
    ]);
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history]);

  // Helper to run the spinner animation simulation
  const runSpinnerSimulation = async () => {
    setIsProcessing(true);
    
    // Helper function for individual spinner
    const spin = async (durationSec: number, message: string) => {
        const frames = ['—', '\\', '|', '/'];
        const interval = 100; // ms
        const steps = (durationSec * 1000) / interval;
        
        // Initial Line
        setHistory(prev => [...prev, `${message} `]);
        
        for (let i = 0; i < steps; i++) {
            await new Promise(r => setTimeout(r, interval));
            setHistory(prev => {
                const newHist = [...prev];
                // Update last line in place to simulate stdout flush/backspace
                newHist[newHist.length - 1] = `${message} ${frames[i % frames.length]}`;
                return newHist;
            });
        }
        
        // Clear spinner char and print Selesai
        setHistory(prev => {
            const newHist = [...prev];
            newHist[newHist.length - 1] = `${message} `; // Remove char
            return newHist;
        });
        setHistory(prev => [...prev, "Selesai."]);
    };

    // Execution Flow based on python script
    setHistory(prev => [...prev, "OMNION menginisialisasi animasi sederhana..."]);
    
    await spin(7, "Analisis data");
    
    setHistory(prev => [...prev, "Animasi pertama selesai."]);
    await new Promise(r => setTimeout(r, 1000)); // sleep(1)
    
    await spin(4, "Memuat modul");
    
    setHistory(prev => [...prev, "Semua proses selesai dengan efisiensi OMNION."]);
    
    setIsProcessing(false);
  };

  const handleCommand = async (cmd: string) => {
    if (!cmd.trim()) {
       setHistory(prev => [...prev, `\u001b[32m${isRoot ? '#' : '$'} \u001b[0m`]);
       return;
    }

    const parts = cmd.trim().split(' ');
    const command = parts[0];
    const args = parts.slice(1);

    // Add command line to history
    setHistory(prev => [...prev, `${isRoot ? '#' : '$'} ${cmd}`]);

    switch (command) {
      case 'clear':
        setHistory([]);
        break;
      case 'ls':
        setHistory(prev => [...prev, "storage  downloads  usr  home  omnion_core  scripts"]);
        break;
      case 'whoami':
        setHistory(prev => [...prev, isRoot ? "root" : `u0_a293`]);
        break;
      case 'pwd':
        setHistory(prev => [...prev, `/data/data/com.termux/files/home${cwd === '~' ? '' : cwd}`]);
        break;
      case 'exit':
        setHistory(prev => [...prev, "logout"]);
        break;
      case 'pkg':
      case 'apt':
        if (args[0] === 'update' || args[0] === 'upgrade') {
          setIsProcessing(true);
          setHistory(prev => [...prev, "Checking for updates..."]);
          await new Promise(r => setTimeout(r, 800));
          setHistory(prev => [...prev, "Testing available mirrors: 1/12... done."]);
          await new Promise(r => setTimeout(r, 600));
          setHistory(prev => [...prev, "All packages are up to date."]);
          setIsProcessing(false);
        } else if (args[0] === 'install') {
          const pkg = args[1];
          if (!pkg) {
             setHistory(prev => [...prev, "Usage: pkg install <package>"]);
          } else {
             setIsProcessing(true);
             setHistory(prev => [...prev, `Checking availability of ${pkg}...`]);
             await new Promise(r => setTimeout(r, 1000));
             setHistory(prev => [...prev, `Downloading ${pkg} (24.5 MB)...`]);
             for(let i=0; i<=10; i++) {
                await new Promise(r => setTimeout(r, 200));
             }
             setHistory(prev => [...prev, `Unpacking ${pkg}...`]);
             await new Promise(r => setTimeout(r, 500));
             setHistory(prev => [...prev, `Setting up ${pkg}...`]);
             setHistory(prev => [...prev, `Done.`]);
             setIsProcessing(false);
          }
        } else {
          setHistory(prev => [...prev, "Usage: pkg [install|update|upgrade]"]);
        }
        break;
      case 'python':
      case 'python3':
         if (args.length === 0) {
           setHistory(prev => [...prev, "Python 3.11.4 (main, Jun  7 2023, 00:00:00) [Clang 14.0.7] on linux"]);
           setHistory(prev => [...prev, 'Type "help", "copyright", "credits" or "license" for more information.']);
           setHistory(prev => [...prev, ">>> exit()"]);
         } else {
            // Check for our specific mock script
            if (args[0] === 'loading_animation.py' || args[0] === 'scripts/loading_animation.py') {
                await runSpinnerSimulation();
            } else {
                setHistory(prev => [...prev, `python: can't open file '${args[0]}': [Errno 2] No such file or directory`]);
            }
         }
         break;
      case 'omnion':
         setHistory(prev => [...prev, "OMNION CORE KERNEL LINKED."]);
         setHistory(prev => [...prev, "Status: OMNIPOTENT"]);
         break;
      default:
        setHistory(prev => [...prev, `bash: ${command}: command not found`]);
    }
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleCommand(input);
      setInput('');
    }
  };

  return (
    <div className="h-full bg-[#1e1e1e] text-gray-300 font-mono text-sm flex flex-col p-2 overflow-hidden">
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto whitespace-pre-wrap break-all pb-4 scrollbar-hide"
        onClick={() => inputRef.current?.focus()}
      >
        {history.map((line, i) => (
          <div key={i} className="min-h-[1.2em]">{line}</div>
        ))}
        {!isProcessing && (
            <div className="flex items-center">
                <span className="text-green-500 mr-2">{isRoot ? '#' : '$'}</span>
                <input
                    ref={inputRef}
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={onKeyDown}
                    className="flex-1 bg-transparent border-none outline-none text-gray-200"
                    autoFocus
                    autoComplete="off"
                    spellCheck="false"
                />
            </div>
        )}
      </div>
      
      {/* Mobile Keyboard Accessory Bar */}
      <div className="h-10 bg-[#2d2d2d] border-t border-[#3e3e3e] flex items-center px-2 gap-2 shrink-0 overflow-x-auto no-scrollbar">
          {['ESC', 'TAB', 'CTRL', 'ALT', '-', '/', '|', 'python', 'ls', 'clear'].map(key => (
              <button 
                key={key}
                onClick={() => setInput(prev => prev + (key === 'python' ? 'python ' : key))}
                className="bg-[#3e3e3e] px-3 py-1.5 rounded text-xs font-bold hover:bg-[#4e4e4e] active:bg-[#5e5e5e] transition-colors whitespace-nowrap"
              >
                  {key}
              </button>
          ))}
      </div>
    </div>
  );
};

export default Termux;