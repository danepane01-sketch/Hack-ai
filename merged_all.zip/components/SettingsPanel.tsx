import React, { useState } from 'react';
import { Theme, AppMode, AppSettings } from '../types';
import { Moon, Sun, Monitor, Heart, Smartphone, Database, Link, Trash2, FileText, Lock, ChevronLeft, LayoutGrid, Activity, ChevronRight, Check } from 'lucide-react';

interface SettingsPanelProps {
  settings: AppSettings;
  setSettings: React.Dispatch<React.SetStateAction<AppSettings>>;
  setMode: (mode: AppMode) => void;
}

const SettingsPanel: React.FC<SettingsPanelProps> = ({ settings, setSettings, setMode }) => {
  const [activeSubMenu, setActiveSubMenu] = useState<string | null>(null);

  // Toggle Logic
  const toggleHaptics = () => {
    if (navigator.vibrate && !settings.haptics.enabled) navigator.vibrate(50);
    setSettings(prev => ({
      ...prev,
      haptics: { ...prev.haptics, enabled: !prev.haptics.enabled }
    }));
  };

  const toggleResponseVibration = () => {
    if (navigator.vibrate && settings.haptics.enabled) navigator.vibrate(20);
    setSettings(prev => ({
      ...prev,
      haptics: { ...prev.haptics, responseVibration: !prev.haptics.responseVibration }
    }));
  };

  // Helper for Theme Cards
  const ThemeCard = ({ id, label, icon: Icon, active }: { id: Theme, label: string, icon: any, active: boolean }) => (
    <button 
      onClick={() => {
        setSettings(prev => ({ ...prev, theme: id }));
        if (settings.haptics.enabled && navigator.vibrate) navigator.vibrate(10);
      }}
      className={`flex flex-col items-center justify-center p-4 rounded-2xl border transition-all duration-300 ${
        active 
          ? 'bg-blue-600/10 border-blue-500 text-blue-500 shadow-[0_0_15px_rgba(37,99,235,0.2)]' 
          : 'bg-[#15151a] border-gray-800 text-gray-400 hover:bg-[#1a1a20]'
      }`}
    >
      <Icon size={24} className="mb-2" />
      <span className="text-xs font-medium">{label}</span>
    </button>
  );

  // Helper for Toggle Items
  const ToggleItem = ({ icon: Icon, label, isOn, onToggle }: any) => (
    <div 
        onClick={onToggle}
        className="flex items-center justify-between py-4 border-b border-gray-800 last:border-0 group cursor-pointer hover:bg-white/5 px-3 -mx-2 transition-colors"
    >
      <div className="flex items-center gap-3">
        <Icon size={20} className="text-gray-500 group-hover:text-gray-300" />
        <span className="text-sm font-medium text-gray-200">{label}</span>
      </div>
      <div className={`w-12 h-7 rounded-full transition-colors relative ${isOn ? 'bg-blue-600' : 'bg-gray-700'}`}>
           <div className={`absolute top-1 left-1 bg-white w-5 h-5 rounded-full shadow-md transition-transform duration-300 ${isOn ? 'translate-x-5' : 'translate-x-0'}`}></div>
      </div>
    </div>
  );

  // Helper for List Items
  const MenuItem = ({ icon: Icon, label, onClick }: any) => (
    <div 
        onClick={onClick}
        className="flex items-center justify-between py-4 border-b border-gray-800 last:border-0 group cursor-pointer hover:bg-white/5 px-3 -mx-2 transition-colors"
    >
      <div className="flex items-center gap-3">
        <Icon size={20} className="text-gray-500 group-hover:text-gray-300" />
        <span className="text-sm font-medium text-gray-200">{label}</span>
      </div>
      <ChevronRight size={16} className="text-gray-600" />
    </div>
  );

  // Sub Menu View
  if (activeSubMenu) {
    return (
        <div className="h-full bg-black text-gray-200 flex flex-col font-sans animate-in slide-in-from-right duration-300">
             <div className="p-4 flex items-center gap-4 border-b border-gray-800 sticky top-0 bg-black/90 backdrop-blur z-20">
                <button onClick={() => setActiveSubMenu(null)} className="p-2 hover:bg-gray-800 rounded-full">
                    <ChevronLeft size={24} />
                </button>
                <h1 className="text-xl font-bold">{activeSubMenu}</h1>
            </div>
            <div className="flex-1 p-6 flex flex-col items-center justify-center text-gray-500">
                <Database size={48} className="mb-4 opacity-50" />
                <p>Simulation Data Mode</p>
                <p className="text-xs mt-2">Omnion Core System</p>
            </div>
        </div>
    );
  }

  // Main Settings View
  return (
    <div className="h-full bg-black text-gray-200 flex flex-col font-sans animate-in fade-in duration-300">
        
        {/* Header */}
        <div className="p-4 flex items-center gap-4 border-b border-gray-800 sticky top-0 bg-black/90 backdrop-blur z-20">
            <button onClick={() => setMode(AppMode.TERMINAL)} className="p-2 hover:bg-gray-800 rounded-full">
                <ChevronLeft size={24} />
            </button>
            <h1 className="text-xl font-bold">Settings</h1>
        </div>

        <div className="flex-1 overflow-y-auto p-4 md:p-6 max-w-2xl mx-auto w-full space-y-8">
            
            {/* Appearance Section */}
            <section>
                <h2 className="text-xs font-bold text-gray-500 mb-4 px-1 uppercase tracking-wider">Appearance</h2>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <ThemeCard id="system" label="System" icon={LayoutGrid} active={settings.theme === 'system'} />
                    <ThemeCard id="foryou" label="For You" icon={Heart} active={settings.theme === 'foryou'} />
                    <ThemeCard id="dark" label="Dark" icon={Moon} active={settings.theme === 'dark'} />
                    <ThemeCard id="light" label="Light" icon={Sun} active={settings.theme === 'light'} />
                </div>
            </section>

            {/* Haptics Section */}
            <section>
                <h2 className="text-xs font-bold text-gray-500 mb-2 px-1 uppercase tracking-wider">Haptics & Vibration</h2>
                <div className="bg-[#0f0f12] rounded-2xl px-4 border border-gray-800">
                    <ToggleItem 
                        icon={Smartphone} 
                        label="When pressing buttons" 
                        isOn={settings.haptics.enabled} 
                        onToggle={toggleHaptics} 
                    />
                    <ToggleItem 
                        icon={Activity} 
                        label="When Omnion is responding" 
                        isOn={settings.haptics.responseVibration} 
                        onToggle={toggleResponseVibration} 
                    />
                </div>
            </section>

            {/* Data Section */}
            <section>
                <h2 className="text-xs font-bold text-gray-500 mb-2 px-1 uppercase tracking-wider">Data & Information</h2>
                <div className="bg-[#0f0f12] rounded-2xl px-4 border border-gray-800">
                    <MenuItem icon={LayoutGrid} label="Customize Omnion" onClick={() => setActiveSubMenu('Customize Omnion')} />
                    <MenuItem icon={Database} label="Data Controls" onClick={() => setActiveSubMenu('Data Controls')} />
                    <MenuItem icon={Link} label="Shared Links" onClick={() => setActiveSubMenu('Shared Links')} />
                    <MenuItem icon={Trash2} label="Recently Deleted" onClick={() => setActiveSubMenu('Recently Deleted')} />
                    <MenuItem icon={FileText} label="Terms of Use" onClick={() => setActiveSubMenu('Terms of Use')} />
                    <MenuItem icon={Lock} label="Privacy Policy" onClick={() => setActiveSubMenu('Privacy Policy')} />
                </div>
            </section>

            <div className="text-center text-xs text-gray-700 font-mono py-8">
                Omnion v5.0.0-SINGULARITY
                <br />
                Build 2024.05.25.RELEASE
            </div>

        </div>
    </div>
  );
};

export default SettingsPanel;