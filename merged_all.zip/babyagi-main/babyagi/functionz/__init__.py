from .core.framework import func

__all__ = ['func']
