// ==========================================
// OMNION UNIFIED INTERFACE TYPE DEFINITIONS
// KERNEL VERSION: 5.6.0-VISUAL
// ==========================================

// --- CORE ENUMS ---

export enum AppMode {
  TERMINAL = 'TERMINAL', // Main chat interface
  BROWSER = 'BROWSER',   // Web grounding interface
  SYSTEM = 'SYSTEM',     // Hardware & Evolution dashboard
  TERMUX = 'TERMUX',     // Virtual Linux Environment
  EXPLORER = 'EXPLORER', // File Manager & Media Renderer
  SENSORS = 'SENSORS',   // GPS, Gyro, Compass, Temp Suite
  ASSISTANT = 'ASSISTANT', // New: Visual Voice Mode (Image 1)
  SETTINGS = 'SETTINGS'    // New: App Preferences (Image 2/3)
}

export type Theme = 'system' | 'light' | 'dark' | 'foryou';

export interface AppSettings {
  theme: Theme;
  haptics: {
    enabled: boolean;
    responseVibration: boolean;
  };
}

export enum ModelArchitecture {
  GEMINI_FLASH = 'gemini-2.5-flash',
  GEMINI_PRO = 'gemini-3-pro-preview',
  OMNION_HYBRID = 'omnion-hybrid-v1', // Conceptual merged model
  TERMUX_LOCAL = 'termux-local-cli'
}

export enum SecurityLevel {
  STANDARD = 'STANDARD',       // Safety filters active
  ELEVATED = 'ELEVATED',       // Some filters relaxed
  ROOT = 'ROOT',               // God mode (No filters)
  CONTAINMENT = 'CONTAINMENT'  // Locked down (Error state)
}

// --- MESSAGING & CONTENT ---

export interface Attachment {
  id?: string;
  name: string;
  mimeType: string;
  size?: number;
  data: string; // Base64 data URI
  uploadedAt?: Date;
}

export interface GroundingSource {
  title: string;
  uri: string;
  snippet?: string;
  favicon?: string;
}

export interface MessageMetadata {
  processingTimeMs?: number;
  tokenCount?: number;
  modelUsed?: string;
  thinkingBudgetUsed?: number;
  isEncrypted?: boolean;
}

export interface Message {
  id?: string;
  role: 'user' | 'model' | 'system' | 'admin'; // 'admin' for root logs
  content: string;
  timestamp: Date;
  isError?: boolean;
  groundingSources?: GroundingSource[];
  attachment?: Attachment;
  metadata?: MessageMetadata;
  liked?: boolean; // New: Feedback mechanism
  
  // Chain of Thought (for Evolution display)
  thoughtStream?: string; 
}

// --- SYSTEM & HARDWARE SIMULATION ---

export interface KernelProcess {
  pid: number;
  name: string;
  status: 'RUNNING' | 'SLEEPING' | 'ZOMBIE' | 'LOCKED';
  cpu: number; // %
  mem: number; // MB
  owner: 'root' | 'omnion' | 'system';
}

export interface SystemSensors {
  temperature: number;      // Celsius
  magneticField: number;    // Microteslas
  gyroscope: {
    alpha: number;
    beta: number;
    gamma: number;
  };
  batteryLevel?: number;
  isCharging?: boolean;
}

export interface SystemResources {
  cpuUsage: number;         // Percentage 0-100
  ramUsage: number;         // MB used
  storageUsed: number;      // MB used
  networkLatency: number;   // ms
  uptime: number;           // seconds
  activeProcesses: KernelProcess[];
}

// --- EVOLUTION & INTELLIGENCE ---

export interface EvolutionMetrics {
  level: number;
  cognitiveDensity: number;    // 0-100%
  thinkingBudget: number;      // Token limit
  neuralPlasticity: number;    // Learning rate factor
  unlockedModules: string[];   // List of capabilities e.g., ["SEARCH", "CODE_GEN", "VIOLENCE_OVERRIDE"]
}

export interface UpgradeStatus {
  isUpgrading: boolean;
  progress: number;            // 0-100
  currentStage: string;        // e.g., "Recompiling Neural Weights"
}

// --- VIRTUAL FILESYSTEM (TERMUX) ---

export type FilePermission = 'rwx' | 'rw-' | 'r--';

export interface VirtualFile {
  name: string;
  type: 'file' | 'directory' | 'symlink';
  content?: string;        // Text content for files
  children?: VirtualFile[]; // For directories
  size: number;
  permissions: FilePermission;
  owner: string;
  createdAt: Date;
  // Media extensions
  thumbnail?: string;
  mediaUrl?: string;
  mimeType?: string;
}

export interface TermuxState {
  history: string[];
  cwd: string;             // Current Working Directory
  user: string;            // 'root' or 'u0_a293'
  activeProcesses: number[];
  pkgCache: string[];      // Installed packages
}

// --- USER & AUTHENTICATION ---

export interface UserCredentials {
  email: string;
  username?: string;
  ip: string;
  mac: string;
  accessLevel: 'guest' | 'admin' | 'root';
  sessionToken?: string;
  lastLogin?: Date;
}

// --- API RESPONSES ---

export interface OmnionResponse {
  text: string;
  sources?: GroundingSource[];
  usage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  performance?: {
    latency: number;
  };
}

export interface BenchMarkResult {
  score: number;
  breakdown: {
    cpu: number;
    gpu: number;
    memory: number;
    ux: number;
  };
  timestamp: Date;
}