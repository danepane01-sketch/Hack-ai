<?hh // strict

use tomzx\HackBot\Core\Logger;

require __DIR__.'/../../../vendor/autoload.php';

Logger::setEnabled(false);