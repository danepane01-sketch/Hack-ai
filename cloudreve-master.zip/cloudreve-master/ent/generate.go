package ent

//go:generate go run -mod=mod entc.go
