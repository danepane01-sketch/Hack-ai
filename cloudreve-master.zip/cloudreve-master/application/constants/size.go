package constants

const (
	MB = 1 << 20
	GB = 1 << 30
	TB = 1 << 40
	PB = 1 << 50
)
